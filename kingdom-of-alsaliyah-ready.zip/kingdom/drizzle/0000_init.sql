CREATE TABLE `system_settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL,
	`description` text,
	`updated_at` integer NOT NULL,
	`updated_by` text
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`national_id` text,
	`account_type` text NOT NULL,
	`full_name` text NOT NULL,
	`phone` text NOT NULL,
	`email` text,
	`password_hash` text NOT NULL,
	`password_salt` text NOT NULL,
	`status` text DEFAULT 'PENDING' NOT NULL,
	`is_supreme_king` integer DEFAULT false NOT NULL,
	`official_title` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_national_id_unique` ON `users` (`national_id`);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_phone_unique` ON `users` (`phone`);
--> statement-breakpoint
CREATE TABLE `civil_records` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`national_id` text NOT NULL,
	`record_type` text NOT NULL,
	`governorate_id` text,
	`city` text,
	`citizenship_status` text DEFAULT 'ACTIVE' NOT NULL,
	`family_book_number` text,
	`head_of_family_id` text,
	`relationship_to_head` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `civil_records_national_id_unique` ON `civil_records` (`national_id`);
--> statement-breakpoint
CREATE TABLE `registration_applications` (
	`id` text PRIMARY KEY NOT NULL,
	`tracking_number` text NOT NULL,
	`full_name` text NOT NULL,
	`account_type` text NOT NULL,
	`submitted_id_number` text,
	`phone` text NOT NULL,
	`email` text,
	`password_hash` text NOT NULL,
	`password_salt` text NOT NULL,
	`governorate_id` text,
	`notes` text,
	`status` text DEFAULT 'UNDER_REVIEW' NOT NULL,
	`reviewer_notes` text,
	`reviewed_by` text,
	`reviewed_at` integer,
	`approved_user_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`reviewed_by`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`approved_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `registration_applications_tracking_number_unique` ON `registration_applications` (`tracking_number`);
--> statement-breakpoint
CREATE TABLE `attachments` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_type` text NOT NULL,
	`owner_id` text NOT NULL,
	`file_name` text NOT NULL,
	`file_type` text NOT NULL,
	`file_size` integer NOT NULL,
	`r2_key` text NOT NULL,
	`uploaded_by` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `attachments_r2_key_unique` ON `attachments` (`r2_key`);
--> statement-breakpoint
CREATE TABLE `governorates` (
	`id` text PRIMARY KEY NOT NULL,
	`name_ar` text NOT NULL,
	`name_en` text NOT NULL,
	`capital_ar` text,
	`description_ar` text NOT NULL,
	`description_en` text NOT NULL,
	`governor_user_id` text,
	`governor_name` text NOT NULL,
	`regions_json` text NOT NULL,
	FOREIGN KEY (`governor_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `entities` (
	`id` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`type` text NOT NULL,
	`name_ar` text NOT NULL,
	`name_en` text NOT NULL,
	`head_name` text NOT NULL,
	`head_title_ar` text NOT NULL,
	`head_user_id` text,
	`deputy_name` text,
	`deputy_user_id` text,
	`deputy_status` text DEFAULT 'NONE',
	`reports_directly_to_king` integer DEFAULT false NOT NULL,
	`description_ar` text,
	`description_en` text,
	FOREIGN KEY (`head_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`deputy_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `entities_code_unique` ON `entities` (`code`);
--> statement-breakpoint
CREATE TABLE `user_roles` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`role_code` text NOT NULL,
	`entity_id` text,
	`position_title_ar` text NOT NULL,
	`permissions_json` text NOT NULL,
	`is_active` integer DEFAULT true NOT NULL,
	`granted_by` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `sms_messages` (
	`id` text PRIMARY KEY NOT NULL,
	`recipient_phone` text NOT NULL,
	`recipient_user_id` text,
	`sender_name` text NOT NULL,
	`message_body` text NOT NULL,
	`otp_code` text,
	`otp_expires_at` integer,
	`is_otp_used` integer DEFAULT false,
	`is_read` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `official_publications` (
	`id` text PRIMARY KEY NOT NULL,
	`decree_number` text,
	`type` text NOT NULL,
	`entity_id` text NOT NULL,
	`title_ar` text NOT NULL,
	`title_en` text,
	`content_ar` text NOT NULL,
	`content_en` text,
	`published_by` text NOT NULL,
	`status` text DEFAULT 'PUBLISHED' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `official_publications_decree_number_unique` ON `official_publications` (`decree_number`);
--> statement-breakpoint
CREATE TABLE `royal_court_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`tracking_number` text NOT NULL,
	`applicant_id` text NOT NULL,
	`request_type` text NOT NULL,
	`subject` text NOT NULL,
	`details` text NOT NULL,
	`is_confidential` integer DEFAULT false NOT NULL,
	`assigned_entity_id` text,
	`status` text DEFAULT 'RECEIVED' NOT NULL,
	`response_text` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`applicant_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `royal_court_requests_tracking_number_unique` ON `royal_court_requests` (`tracking_number`);
--> statement-breakpoint
CREATE TABLE `incident_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`report_number` text NOT NULL,
	`reporter_id` text,
	`category` text NOT NULL,
	`is_sighting` integer DEFAULT false NOT NULL,
	`routed_entity_id` text NOT NULL,
	`location_text` text NOT NULL,
	`description` text NOT NULL,
	`status` text DEFAULT 'UNDER_VERIFICATION' NOT NULL,
	`resolution_notes` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `incident_reports_report_number_unique` ON `incident_reports` (`report_number`);
--> statement-breakpoint
CREATE TABLE `budgets` (
	`id` text PRIMARY KEY NOT NULL,
	`fiscal_year` text NOT NULL,
	`entity_id` text NOT NULL,
	`proposed_amount` integer NOT NULL,
	`approved_amount` integer DEFAULT 0,
	`spent_amount` integer DEFAULT 0,
	`status` text DEFAULT 'SUBMITTED' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `audit_investigations` (
	`id` text PRIMARY KEY NOT NULL,
	`case_number` text NOT NULL,
	`target_entity_id` text NOT NULL,
	`target_official_name` text NOT NULL,
	`reason` text NOT NULL,
	`evidence_summary` text NOT NULL,
	`status` text DEFAULT 'OPEN' NOT NULL,
	`king_decision` text,
	`opened_by` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `audit_investigations_case_number_unique` ON `audit_investigations` (`case_number`);
--> statement-breakpoint
CREATE TABLE `national_alerts` (
	`id` text PRIMARY KEY NOT NULL,
	`alert_type` text NOT NULL,
	`severity` text NOT NULL,
	`affected_region` text NOT NULL,
	`instructions` text NOT NULL,
	`issuing_entity` text NOT NULL,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`actor_user_id` text,
	`actor_name` text NOT NULL,
	`actor_role` text NOT NULL,
	`entity_id` text,
	`action_type` text NOT NULL,
	`target_type` text NOT NULL,
	`target_id` text NOT NULL,
	`previous_data_json` text,
	`new_data_json` text,
	`reason` text,
	`outcome` text NOT NULL,
	`created_at` integer NOT NULL
);
