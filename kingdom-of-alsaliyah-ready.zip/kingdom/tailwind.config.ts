import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        saliyah: {
          green: "#006C35",
          darkGreen: "#004D25",
          lightGreen: "#E6F2EC",
          gold: "#C5A059",
          slate: "#1E293B",
          bg: "#F8FAFC"
        }
      }
    },
  },
  plugins: [],
};
export default config;
