# بوابة دولة المملكة العربية الصالية (Kingdom of Al-Saliyah Portal)

منصة حكومية إلكترونية متكاملة مبنية بـ **Next.js (App Router) + TypeScript + Drizzle ORM** ومهيأة للعمل على بنية **Cloudflare (Pages + D1 + R2)** على مدار 24/7.

> **بناء جاهز**: تم توليد ترحيلات قاعدة البيانات مسبقاً (مجلد `drizzle/`). لا حاجة لتشغيل `db:generate` إلا إذا عدّلت الـ schema.

---

## خطوات النشر والتشغيل على Cloudflare (بدون مشاركة أي أسرار)

### 1. تثبيت الحزم
```bash
npm install --legacy-peer-deps
```

### 2. إنشاء قاعدة بيانات Cloudflare D1 وتخزين R2
من الطرفية (بعد تسجيل الدخول بـ `npx wrangler login`):
```bash
npx wrangler d1 create alsaliyah-db
npx wrangler r2 bucket create alsaliyah-documents
```
انسخ `database_id` الناتج وضعه في ملف `wrangler.toml` مكان `REPLACE_WITH_YOUR_D1_DATABASE_ID`.

### 3. تطبيق الجداول على قاعدة البيانات السحابية
```bash
npm run db:migrate:prod
```

### 4. النشر على Cloudflare Pages
```bash
npm run deploy
```
ثم من لوحة تحكم **Cloudflare Dashboard > Pages > Settings > Functions**:
1. اربط **D1 database binding** بالاسم `DB` -> `alsaliyah-db`.
2. اربط **R2 bucket binding** بالاسم `DOCS_BUCKET` -> `alsaliyah-documents`.
3. أضف متغير البيئة السري `SESSION_SECRET` (نص عشوائي طويل لتأمين الجلسات).

### 5. التأسيس الأولي لحساب الملك زياد
افتح رابط موقعك المنشور على Cloudflare لأول مرة:
- ستظهر لك شاشة **التأسيس الأولي لبوابة المملكة العربية الصالية**.
- أدخل رقم الهوية الملكية ورقم الجوال وكلمة المرور الخاصة بالملك **زياد بندر سعد العمري**.
- بمجرد الاعتماد، يتم إنشاء حساب الملك، المحافظات الثلاث، والـ 35 وزارة المعتمدة في قاعدة البيانات.

---

## تشغيل محلي (للتطوير)
```bash
npm install --legacy-peer-deps
npx wrangler d1 create alsaliyah-db --local   # اختياري
npm run db:migrate:local
npm run dev
```

---

## ملاحظات
- المشروع مهيأ لـ Cloudflare Pages مع `nodejs_compat`.
- الجلسات تستخدم JWT مع `SESSION_SECRET`.
- المستندات تُحفظ في R2 عبر binding اسمه `DOCS_BUCKET`.
