import { getRequestContext } from "@cloudflare/next-on-pages";
import { drizzle } from "drizzle-orm/d1";
import * as schema from "@/db/schema";

export interface CloudflareEnv {
  DB: D1Database;
  DOCS_BUCKET: R2Bucket;
  SESSION_SECRET?: string;
}

export function getEnv(): CloudflareEnv {
  const ctx = getRequestContext();
  return ctx.env as unknown as CloudflareEnv;
}

export function getDb() {
  const env = getEnv();
  return drizzle(env.DB, { schema });
}

export function getBucket(): R2Bucket {
  return getEnv().DOCS_BUCKET;
}
