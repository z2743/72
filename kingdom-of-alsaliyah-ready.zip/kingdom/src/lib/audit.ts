import { getDb } from "./cloudflare";
import { auditLogs } from "@/db/schema";

export async function logAuditEvent(params: {
  actorUserId?: string | null;
  actorName: string;
  actorRole: string;
  entityId?: string | null;
  actionType: string;
  targetType: string;
  targetId: string;
  previousData?: unknown;
  newData?: unknown;
  reason?: string;
  outcome: "SUCCESS" | "DENIED" | "FAILED";
}) {
  const db = getDb();
  await db.insert(auditLogs).values({
    id: crypto.randomUUID(),
    actorUserId: params.actorUserId ?? null,
    actorName: params.actorName,
    actorRole: params.actorRole,
    entityId: params.entityId ?? null,
    actionType: params.actionType,
    targetType: params.targetType,
    targetId: params.targetId,
    previousDataJson: params.previousData ? JSON.stringify(params.previousData) : null,
    newDataJson: params.newData ? JSON.stringify(params.newData) : null,
    reason: params.reason ?? null,
    outcome: params.outcome,
    createdAt: new Date(),
  });
}
