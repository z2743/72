import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { getEnv } from "./cloudflare";

const COOKIE_NAME = "saliyah_session";

function getSecretKey() {
  const env = getEnv();
  const secret = env.SESSION_SECRET || "default-dev-secret-change-in-cloudflare-dashboard";
  return new TextEncoder().encode(secret);
}

export interface SessionPayload {
  userId: string;
  nationalId: string;
  fullName: string;
  accountType: string;
  isSupremeKing: boolean;
}

export async function createSession(payload: SessionPayload) {
  const token = await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("12h")
    .sign(getSecretKey());

  cookies().set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12,
  });
}

export async function getSession(): Promise<SessionPayload | null> {
  const cookie = cookies().get(COOKIE_NAME)?.value;
  if (!cookie) return null;

  try {
    const { payload } = await jwtVerify(cookie, getSecretKey());
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

export function destroySession() {
  cookies().delete(COOKIE_NAME);
}
