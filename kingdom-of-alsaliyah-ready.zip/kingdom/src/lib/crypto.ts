// Web Crypto API utilities (100% compatible with Cloudflare Workers / Edge Runtime)

export async function hashPassword(password: string, existingSalt?: string): Promise<{ hash: string; salt: string }> {
  const encoder = new TextEncoder();
  const saltBytes = existingSalt
    ? Uint8Array.from(atob(existingSalt), (c) => c.charCodeAt(0))
    : crypto.getRandomValues(new Uint8Array(16));

  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveBits"]
  );

  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: saltBytes,
      iterations: 100000,
      hash: "SHA-256",
    },
    keyMaterial,
    256
  );

  const hashArray = Array.from(new Uint8Array(derivedBits));
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  const saltBase64 = existingSalt || btoa(String.fromCharCode(...saltBytes));

  return { hash: hashHex, salt: saltBase64 };
}

export async function verifyPassword(password: string, storedHash: string, storedSalt: string): Promise<boolean> {
  const { hash } = await hashPassword(password, storedSalt);
  return hash === storedHash;
}

export function generateOtpCode(): string {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  return String(100000 + (array[0] % 900000));
}

export function generateTrackingNumber(prefix: string): string {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  const year = new Date().getFullYear();
  return `${prefix}-${year}-${String(100000 + (array[0] % 900000))}`;
}

export function generateCandidateNationalId(accountType: "CITIZEN" | "RESIDENT"): string {
  const prefix = accountType === "CITIZEN" ? "1" : "2";
  const array = new Uint32Array(2);
  crypto.getRandomValues(array);
  const nineDigits = String(array[0] % 1000000000).padStart(9, "0");
  return `${prefix}${nineDigits}`;
}
