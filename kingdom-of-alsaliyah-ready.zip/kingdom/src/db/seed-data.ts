// Exact official structure of the Kingdom of Al-Saliyah per approved requirements document

export const INITIAL_SETTINGS = [
  { key: "stc_prefix", value: "UNSET", description: "بادئة أرقام شركة STC الصالية (تُحدد من لوحة الإدارة)" },
  { key: "zain_prefix", value: "UNSET", description: "بادئة أرقام شركة زين الصالية (تُحدد من لوحة الإدارة)" },
  { key: "gov_mail_domain", value: "saliyah.gov.temp", description: "نطاق البريد الحكومي المؤقت (قابل للتعديل)" },
  { key: "portal_mode", value: "INVITE_AND_APPROVAL", description: "نظام البوابة الخاص (موافقة الجوازات إلزامية)" },
];

export const GOVERNORATES_DATA = [
  {
    id: "gov-sajjadah",
    nameAr: "محافظة السجادة",
    nameEn: "Al-Sajjadah Governorate",
    capitalAr: "مدينة السجادة",
    descriptionAr: "العاصمة الإدارية والسياسية للمملكة العربية الصالية، وتضم مدينة السجادة ومنطقة الكراسي.",
    descriptionEn: "The administrative and political capital of the Kingdom of Al-Saliyah, including Al-Sajjadah City and Al-Karasi District.",
    governorName: "قندس بن زياد بن بندر العمري",
    regionsJson: JSON.stringify({
      capital: "مدينة السجادة",
      districts: ["منطقة الكراسي"],
      notes: "مقر الحكم والعاصمة الرسمية للمملكة"
    })
  },
  {
    id: "gov-mitjar",
    nameAr: "محافظة المتجار",
    nameEn: "Al-Mitjar Governorate",
    capitalAr: "مدينة المنفذ",
    descriptionAr: "محافظة صناعية وتجارية وليست منطقة سكنية بالأساس. تضم مدينة المنفذ (منطقة الزبايل، منطقة الجزم، منفذ تجاري حدودي) ومدينة المطبخ الصناعية (75% صناعات غذائية و25% صناعات أخرى).",
    descriptionEn: "An industrial and commercial governorate (not primarily residential). Includes Al-Manfadh City (Al-Zabayil, Al-Jazam, Commercial Border Crossing) and Al-Matbakh Industrial City.",
    governorName: "كوب بن زياد بن بندر العمري",
    regionsJson: JSON.stringify({
      cities: [
        {
          name: "مدينة المنفذ",
          districts: ["منطقة الزبايل", "منطقة الجزم"],
          features: ["منفذ تجاري حدودي", "إدارة الكهرباء الرئيسية للمملكة في منطقة الزبايل"]
        },
        {
          name: "مدينة المطبخ",
          type: "مدينة صناعية",
          ownership: "ليست مملوكة بالكامل للمملكة",
          industrySplit: "75% صناعات مرتبطة بالأغذية، 25% صناعات أخرى وخدمات",
          beaches: false
        }
      ]
    })
  },
  {
    id: "gov-aqar",
    nameAr: "محافظة عقار",
    nameEn: "Aqar Governorate",
    capitalAr: "عقار",
    descriptionAr: "تضم الأراضي والعقارات، ومصنع مياه (تفاصيل الملكية قيد التحديد)، وبعض إدارات الكهرباء.",
    descriptionEn: "Includes lands and real estate, a water bottling plant (ownership details pending), and regional electricity administrations.",
    governorName: "خرفون بن خروف الخرفي الخرفاني",
    regionsJson: JSON.stringify({
      assets: ["الأراضي والعقارات", "مصنع مياه (ملكية غير محددة بالكامل بعد)", "بعض إدارات الكهرباء"]
    })
  }
];

export const MINISTRIES_AND_ENTITIES = [
  // Crown Prince & Prime Minister Office
  {
    id: "ent-pm-office",
    code: "PM_OFFICE",
    type: "AUTHORITY",
    nameAr: "رئاسة مجلس الوزراء",
    nameEn: "Presidency of the Council of Ministers",
    headName: "قطبي بن زياد بن بندر العمري",
    headTitleAr: "ولي العهد ورئيس مجلس الوزراء",
    reportsDirectlyToKing: true
  },
  // Civil Aviation Authority (Directly under King Ziad - NO other minister)
  {
    id: "ent-gaca",
    code: "CIVIL_AVIATION",
    type: "AUTHORITY",
    nameAr: "هيئة الطيران المدني",
    nameEn: "Civil Aviation Authority",
    headName: "زياد بندر سعد العمري",
    headTitleAr: "تحت الإشراف المباشر للملك زياد",
    reportsDirectlyToKing: true
  },
  // Royal Court & Audit Bureau
  {
    id: "ent-royal-court",
    code: "ROYAL_COURT",
    type: "ROYAL_COURT",
    nameAr: "الديوان الملكي الصالي",
    nameEn: "Al-Saliyah Royal Court",
    headName: "زياد بندر سعد العمري",
    headTitleAr: "خادم الديار الصالية",
    reportsDirectlyToKing: true
  },
  {
    id: "ent-audit-bureau",
    code: "AUDIT_BUREAU",
    type: "AUDIT_BUREAU",
    nameAr: "ديوان المحاسبة والرقابة المالية",
    nameEn: "General Bureau of Accounting and Financial Oversight",
    headName: "مرتبط بالملك مباشرة",
    headTitleAr: "جهة رقابية مستقلة",
    reportsDirectlyToKing: true
  },
  // 35 Approved Ministries (Strictly NO Ministry of Hajj and Umrah)
  { id: "min-foreign", code: "MOFA", type: "MINISTRY", nameAr: "وزارة الخارجية", nameEn: "Ministry of Foreign Affairs", headName: "كسلان بن زياد بن بندر العمري", headTitleAr: "وزير الخارجية", reportsDirectlyToKing: false },
  { id: "min-interior", code: "MOI", type: "MINISTRY", nameAr: "وزارة الداخلية", nameEn: "Ministry of Interior", headName: "قندس بن زياد بن بندر العمري", headTitleAr: "وزير الداخلية", reportsDirectlyToKing: false },
  { id: "min-defense", code: "MOD", type: "MINISTRY", nameAr: "وزارة الدفاع", nameEn: "Ministry of Defense", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير الدفاع", deputyName: "خرفون بن خروف الخرفي الخرفاني", deputyStatus: "APPROVED", reportsDirectlyToKing: false },
  { id: "min-finance", code: "MOF", type: "MINISTRY", nameAr: "وزارة المالية", nameEn: "Ministry of Finance", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير المالية", reportsDirectlyToKing: false },
  { id: "min-justice", code: "MOJ", type: "MINISTRY", nameAr: "وزارة العدل", nameEn: "Ministry of Justice", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير العدل", reportsDirectlyToKing: false },
  { id: "min-health", code: "MOH", type: "MINISTRY", nameAr: "وزارة الصحة", nameEn: "Ministry of Health", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الصحة", reportsDirectlyToKing: false },
  { id: "min-education", code: "MOE", type: "MINISTRY", nameAr: "وزارة التعليم", nameEn: "Ministry of Education", headName: "كوب بن زياد بن بندر العمري", headTitleAr: "وزير التعليم", reportsDirectlyToKing: false },
  { id: "min-energy", code: "MOEN", type: "MINISTRY", nameAr: "وزارة الطاقة", nameEn: "Ministry of Energy", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير الطاقة", reportsDirectlyToKing: false },
  { id: "min-commerce", code: "MOC", type: "MINISTRY", nameAr: "وزارة التجارة", nameEn: "Ministry of Commerce", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير التجارة", reportsDirectlyToKing: false },
  { id: "min-transport", code: "MOT", type: "MINISTRY", nameAr: "وزارة النقل والخدمات اللوجستية", nameEn: "Ministry of Transport and Logistic Services", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير النقل والخدمات اللوجستية", reportsDirectlyToKing: false },
  { id: "min-media", code: "MOM", type: "MINISTRY", nameAr: "وزارة الإعلام", nameEn: "Ministry of Media", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير الإعلام", reportsDirectlyToKing: false },
  { id: "min-industry", code: "MOIN", type: "MINISTRY", nameAr: "وزارة الصناعة", nameEn: "Ministry of Industry", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير الصناعة", reportsDirectlyToKing: false },
  { id: "min-investment", code: "MOINV", type: "MINISTRY", nameAr: "وزارة الاستثمار", nameEn: "Ministry of Investment", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير الاستثمار", reportsDirectlyToKing: false },
  { id: "min-housing", code: "MOHS", type: "MINISTRY", nameAr: "وزارة الإسكان", nameEn: "Ministry of Housing", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير الإسكان", reportsDirectlyToKing: false },
  { id: "min-environment", code: "MEWA", type: "MINISTRY", nameAr: "وزارة البيئة والمياه والزراعة", nameEn: "Ministry of Environment, Water and Agriculture", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير البيئة والمياه والزراعة", reportsDirectlyToKing: false },
  { id: "min-mcit", code: "MCIT", type: "MINISTRY", nameAr: "وزارة الاتصالات وتقنية المعلومات", nameEn: "Ministry of Communications and Information Technology", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الاتصالات وتقنية المعلومات", reportsDirectlyToKing: false },
  { id: "min-culture", code: "MOCUL", type: "MINISTRY", nameAr: "وزارة الثقافة", nameEn: "Ministry of Culture", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير الثقافة", reportsDirectlyToKing: false },
  { id: "min-tourism", code: "MOTOUR", type: "MINISTRY", nameAr: "وزارة السياحة", nameEn: "Ministry of Tourism", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير السياحة", reportsDirectlyToKing: false },
  { id: "min-sports", code: "MOS", type: "MINISTRY", nameAr: "وزارة الرياضة", nameEn: "Ministry of Sport", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير الرياضة", reportsDirectlyToKing: false },
  { id: "min-hrsd", code: "HRSD", type: "MINISTRY", nameAr: "وزارة الموارد البشرية والتنمية الاجتماعية", nameEn: "Ministry of Human Resources and Social Development", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الموارد البشرية والتنمية الاجتماعية", reportsDirectlyToKing: false },
  { id: "min-municipal", code: "MOMRA", type: "MINISTRY", nameAr: "وزارة الشؤون البلدية والقروية", nameEn: "Ministry of Municipal and Rural Affairs", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الشؤون البلدية والقروية", reportsDirectlyToKing: false },
  { id: "min-planning", code: "MOPD", type: "MINISTRY", nameAr: "وزارة التخطيط والتنمية", nameEn: "Ministry of Planning and Development", headName: "أبو شخطه بن شخطون الشخطي الشيخطاني", headTitleAr: "وزير التخطيط والتنمية", reportsDirectlyToKing: false },
  { id: "min-awqaf", code: "MOIA", type: "MINISTRY", nameAr: "وزارة الأوقاف والشؤون الدينية", nameEn: "Ministry of Endowments and Religious Affairs", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير الأوقاف والشؤون الدينية", reportsDirectlyToKing: false },
  { id: "min-youth", code: "MOY", type: "MINISTRY", nameAr: "وزارة الشباب", nameEn: "Ministry of Youth", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الشباب", reportsDirectlyToKing: false },
  { id: "min-governorates", code: "MOGA", type: "MINISTRY", nameAr: "وزارة شؤون المحافظات", nameEn: "Ministry of Governorates Affairs", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير شؤون المحافظات", reportsDirectlyToKing: false },
  { id: "min-livestock", code: "MOLFS", type: "MINISTRY", nameAr: "وزارة الثروة الحيوانية والسمكية", nameEn: "Ministry of Livestock and Fisheries", headName: "كوب بن زياد بن بندر العمري", headTitleAr: "وزير الثروة الحيوانية والسمكية", reportsDirectlyToKing: false },
  { id: "min-emergency", code: "MOEDM", type: "MINISTRY", nameAr: "وزارة الطوارئ وإدارة الكوارث", nameEn: "Ministry of Emergency and Disaster Management", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير الطوارئ وإدارة الكوارث", reportsDirectlyToKing: false },
  { id: "min-minerals", code: "MOMR", type: "MINISTRY", nameAr: "وزارة الثروة المعدنية", nameEn: "Ministry of Mineral Resources", headName: "كوب بن زياد بن بندر العمري", headTitleAr: "وزير الثروة المعدنية", reportsDirectlyToKing: false },
  { id: "min-maritime", code: "MOMP", type: "MINISTRY", nameAr: "وزارة النقل البحري والموانئ", nameEn: "Ministry of Maritime Transport and Ports", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير النقل البحري والموانئ", reportsDirectlyToKing: false },
  { id: "min-food", code: "MOFS", type: "MINISTRY", nameAr: "وزارة الأمن الغذائي", nameEn: "Ministry of Food Security", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الأمن الغذائي", reportsDirectlyToKing: false },
  { id: "min-consumer", code: "MOCA", type: "MINISTRY", nameAr: "وزارة شؤون المستهلك", nameEn: "Ministry of Consumer Affairs", headName: "كوب بن زياد بن بندر العمري", headTitleAr: "وزير شؤون المستهلك", reportsDirectlyToKing: false },
  { id: "min-statistics", code: "MOSC", type: "MINISTRY", nameAr: "وزارة الإحصاء والتعداد", nameEn: "Ministry of Statistics and Census", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الإحصاء والتعداد", reportsDirectlyToKing: false },
  { id: "min-nuclear", code: "MONE", type: "MINISTRY", nameAr: "وزارة الطاقة النووية", nameEn: "Ministry of Nuclear Energy", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير الطاقة النووية", reportsDirectlyToKing: false },
  { id: "min-space", code: "MOSC_SPACE", type: "MINISTRY", nameAr: "وزارة اتصالات الفضاء", nameEn: "Ministry of Space Communications", headName: "خرفون بن خروف الخرفي الخرفاني", headTitleAr: "وزير اتصالات الفضاء", reportsDirectlyToKing: false },
  { id: "min-antiquities", code: "MOAH", type: "MINISTRY", nameAr: "وزارة الآثار والتراث", nameEn: "Ministry of Antiquities and Heritage", headName: "جدو بن جدون الجدي البطريقي", headTitleAr: "وزير الآثار والتراث", reportsDirectlyToKing: false }
];
