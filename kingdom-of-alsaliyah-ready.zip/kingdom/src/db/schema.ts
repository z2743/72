import { sqliteTable, text, integer, uniqueIndex } from "drizzle-orm/sqlite-core";

// 1. System Settings (Configurable prefixes, mail domains, unfinalized rules)
export const systemSettings = sqliteTable("system_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
  updatedBy: text("updated_by"),
});

// 2. Users & Core Identity Accounts
export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  nationalId: text("national_id").unique(), // Generated upon Passport approval (10 digits: 1xxx for citizen, 2xxx for resident)
  accountType: text("account_type").notNull(), // 'KING' | 'CITIZEN' | 'RESIDENT'
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull().unique(),
  email: text("email"),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  status: text("status").notNull().default("PENDING"), // 'PENDING' | 'ACTIVE' | 'SUSPENDED' | 'REJECTED'
  isSupremeKing: integer("is_supreme_king", { mode: "boolean" }).notNull().default(false),
  officialTitle: text("official_title"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
});

// 3. Civil Registry & Family Records (كرت العائلة وسجل الأسرة)
export const civilRecords = sqliteTable("civil_records", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  nationalId: text("national_id").notNull().unique(),
  recordType: text("record_type").notNull(), // 'CITIZEN' | 'RESIDENT'
  governorateId: text("governorate_id"),
  city: text("city"),
  citizenshipStatus: text("citizenship_status").notNull().default("ACTIVE"), // 'ACTIVE' | 'REVOKED' | 'RENOUNCED'
  familyBookNumber: text("family_book_number"),
  headOfFamilyId: text("head_of_family_id"),
  relationshipToHead: text("relationship_to_head"), // 'HEAD' | 'SPOUSE' | 'CHILD' | 'DEPENDENT'
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 4. Registration & Passport Applications (طلبات التسجيل وإدارة الجوازات)
export const registrationApplications = sqliteTable("registration_applications", {
  id: text("id").primaryKey(),
  trackingNumber: text("tracking_number").notNull().unique(),
  fullName: text("full_name").notNull(),
  accountType: text("account_type").notNull(), // 'CITIZEN' | 'RESIDENT'
  submittedIdNumber: text("submitted_id_number"), // Existing passport/ID if any
  phone: text("phone").notNull(),
  email: text("email"),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  governorateId: text("governorate_id"),
  notes: text("notes"),
  status: text("status").notNull().default("UNDER_REVIEW"), // 'UNDER_REVIEW' | 'DOCS_REQUIRED' | 'APPROVED' | 'REJECTED'
  reviewerNotes: text("reviewer_notes"),
  reviewedBy: text("reviewed_by").references(() => users.id),
  reviewedAt: integer("reviewed_at", { mode: "timestamp" }),
  approvedUserId: text("approved_user_id").references(() => users.id),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
});

// 5. Secure Attachments & Documents (R2 Metadata)
export const attachments = sqliteTable("attachments", {
  id: text("id").primaryKey(),
  ownerType: text("owner_type").notNull(), // 'REGISTRATION_APP' | 'ADDITIONAL_DOC' | 'ROYAL_COURT' | 'REPORT' | 'DECREE'
  ownerId: text("owner_id").notNull(),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  r2Key: text("r2_key").notNull().unique(),
  uploadedBy: text("uploaded_by"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 6. Governorates & Regions (المحافظات والمدن)
export const governorates = sqliteTable("governorates", {
  id: text("id").primaryKey(),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  capitalAr: text("capital_ar"),
  descriptionAr: text("description_ar").notNull(),
  descriptionEn: text("description_en").notNull(),
  governorUserId: text("governor_user_id").references(() => users.id),
  governorName: text("governor_name").notNull(),
  regionsJson: text("regions_json").notNull(), // JSON array of cities/regions & administrative notes
});

// 7. Ministries & Sovereign Authorities (الوزارات والهيئات)
export const entities = sqliteTable("entities", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  type: text("type").notNull(), // 'MINISTRY' | 'AUTHORITY' | 'ROYAL_COURT' | 'AUDIT_BUREAU' | 'STATS_CENTER'
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  headName: text("head_name").notNull(),
  headTitleAr: text("head_title_ar").notNull(),
  headUserId: text("head_user_id").references(() => users.id),
  deputyName: text("deputy_name"),
  deputyUserId: text("deputy_user_id").references(() => users.id),
  deputyStatus: text("deputy_status").default("NONE"), // 'NONE' | 'NOMINATED' | 'APPROVED'
  reportsDirectlyToKing: integer("reports_directly_to_king", { mode: "boolean" }).notNull().default(false),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
});

// 8. Multi-Position Official Roles & RBAC (دعم تعدد المناصب للشخص الواحد بدون تكرار الحساب)
export const userRoles = sqliteTable("user_roles", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  roleCode: text("role_code").notNull(), // 'KING' | 'CROWN_PRINCE_PM' | 'MINISTER' | 'DEPUTY_MINISTER' | 'GOVERNOR' | 'PASSPORT_OFFICER' | 'ROYAL_COURT_STAFF' | 'AUDIT_STAFF' | 'ENTITY_STAFF'
  entityId: text("entity_id"), // Linked ministry, governorate, or authority
  positionTitleAr: text("position_title_ar").notNull(),
  permissionsJson: text("permissions_json").notNull(), // Fine-grained permissions array
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  grantedBy: text("granted_by"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 9. Simulated SMS & OTP Box (نظام محاكاة الرسائل النصية ورموز التحقق)
export const smsMessages = sqliteTable("sms_messages", {
  id: text("id").primaryKey(),
  recipientPhone: text("recipient_phone").notNull(),
  recipientUserId: text("recipient_user_id"),
  senderName: text("sender_name").notNull(), // e.g., 'الجوازات الصالية', 'الديوان الملكي', 'بوابة الصالية'
  messageBody: text("message_body").notNull(),
  otpCode: text("otp_code"), // Populated if OTP
  otpExpiresAt: integer("otp_expires_at", { mode: "timestamp" }),
  isOtpUsed: integer("is_otp_used", { mode: "boolean" }).default(false),
  isRead: integer("is_read", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 10. Official News, Decrees & Announcements (الأخبار والقرارات والتعاميم)
export const officialPublications = sqliteTable("official_publications", {
  id: text("id").primaryKey(),
  decreeNumber: text("decree_number").unique(),
  type: text("type").notNull(), // 'ROYAL_ORDER' | 'DECREE' | 'CIRCULAR' | 'NEWS'
  entityId: text("entity_id").notNull(),
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en"),
  contentAr: text("content_ar").notNull(),
  contentEn: text("content_en"),
  publishedBy: text("published_by").notNull(),
  status: text("status").notNull().default("PUBLISHED"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 11. Royal Court Petitions & Confidential Requests (الديوان الملكي والطلبات السرية)
export const royalCourtRequests = sqliteTable("royal_court_requests", {
  id: text("id").primaryKey(),
  trackingNumber: text("tracking_number").notNull().unique(),
  applicantId: text("applicant_id").notNull().references(() => users.id),
  requestType: text("request_type").notNull(), // 'PETITION' | 'COMPLAINT' | 'GRIEVANCE' | 'ASSISTANCE'
  subject: text("subject").notNull(),
  details: text("details").notNull(),
  isConfidential: integer("is_confidential", { mode: "boolean" }).notNull().default(false), // Visible ONLY to King & authorized Royal Court staff
  assignedEntityId: text("assigned_entity_id"),
  status: text("status").notNull().default("RECEIVED"), // 'RECEIVED' | 'REFERRED' | 'ESCALATED_TO_KING' | 'CLOSED'
  responseText: text("response_text"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull(),
});

// 12. Central Operations & Incident Reports (مركز البلاغات والعمليات والمشاهدات)
export const incidentReports = sqliteTable("incident_reports", {
  id: text("id").primaryKey(),
  reportNumber: text("report_number").notNull().unique(),
  reporterId: text("reporter_id").references(() => users.id),
  category: text("category").notNull(), // 'DRUGS' | 'FIRE' | 'TRAFFIC' | 'SECURITY' | 'HEALTH' | 'ENVIRONMENT' | 'SIGHTING'
  isSighting: integer("is_sighting", { mode: "boolean" }).notNull().default(false), // Logged as unconfirmed observation
  routedEntityId: text("routed_entity_id").notNull(),
  locationText: text("location_text").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("UNDER_VERIFICATION"), // 'UNDER_VERIFICATION' | 'IN_PROGRESS' | 'RESOLVED'
  resolutionNotes: text("resolution_notes"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 13. Government Budgets & Audit Bureau Investigations (الميزانيات وديوان المحاسبة والرقابة)
export const budgets = sqliteTable("budgets", {
  id: text("id").primaryKey(),
  fiscalYear: text("fiscal_year").notNull(),
  entityId: text("entity_id").notNull(),
  proposedAmount: integer("proposed_amount").notNull(),
  approvedAmount: integer("approved_amount").default(0),
  spentAmount: integer("spent_amount").default(0),
  status: text("status").notNull().default("SUBMITTED"), // 'SUBMITTED' | 'FINANCE_REVIEW' | 'KING_APPROVED' | 'REJECTED'
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

export const auditInvestigations = sqliteTable("audit_investigations", {
  id: text("id").primaryKey(),
  caseNumber: text("case_number").notNull().unique(),
  targetEntityId: text("target_entity_id").notNull(),
  targetOfficialName: text("target_official_name").notNull(),
  reason: text("reason").notNull(),
  evidenceSummary: text("evidence_summary").notNull(),
  status: text("status").notNull().default("OPEN"), // 'OPEN' | 'REFERRED_TO_KING' | 'CLOSED'
  kingDecision: text("king_decision"),
  openedBy: text("opened_by").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 14. National Alerts (التنبيهات الوطنية)
export const nationalAlerts = sqliteTable("national_alerts", {
  id: text("id").primaryKey(),
  alertType: text("alert_type").notNull(),
  severity: text("severity").notNull(), // 'INFO' | 'WARNING' | 'CRITICAL'
  affectedRegion: text("affected_region").notNull(),
  instructions: text("instructions").notNull(),
  issuingEntity: text("issuing_entity").notNull(),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// 15. Immutable Central Audit Log (سجل التدقيق المركزي غير القابل للتلاعب)
export const auditLogs = sqliteTable("audit_logs", {
  id: text("id").primaryKey(),
  actorUserId: text("actor_user_id"),
  actorName: text("actor_name").notNull(),
  actorRole: text("actor_role").notNull(),
  entityId: text("entity_id"),
  actionType: text("action_type").notNull(),
  targetType: text("target_type").notNull(),
  targetId: text("target_id").notNull(),
  previousDataJson: text("previous_data_json"),
  newDataJson: text("new_data_json"),
  reason: text("reason"),
  outcome: text("outcome").notNull(), // 'SUCCESS' | 'DENIED' | 'FAILED'
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});
