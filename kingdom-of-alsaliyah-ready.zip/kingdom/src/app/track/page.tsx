"use client";

import React, { useState, useEffect, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Search, MessageSquare, Upload, ArrowRight, CheckCircle2, Clock, AlertCircle, XCircle } from "lucide-react";

function TrackContent() {
  const searchParams = useSearchParams();
  const [trackingNumber, setTrackingNumber] = useState(searchParams.get("trackingNumber") || "");
  const [phone, setPhone] = useState(searchParams.get("phone") || "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [data, setData] = useState<{
    application: {
      trackingNumber: string;
      fullName: string;
      accountType: string;
      status: string;
      reviewerNotes?: string;
      issuedNationalId?: string;
    };
    smsInbox: Array<{
      id: string;
      senderName: string;
      messageBody: string;
      createdAt: string;
    }>;
  } | null>(null);

  const [extraFile, setExtraFile] = useState<File | null>(null);
  const [uploadingExtra, setUploadingExtra] = useState(false);

  async function fetchStatus(tNum = trackingNumber, ph = phone) {
    if (!tNum || !ph) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(
        `/api/registration/track?trackingNumber=${encodeURIComponent(tNum)}&phone=${encodeURIComponent(ph)}`
      );
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || "لم يتم العثور على الطلب");
        setData(null);
      } else {
        setData(json);
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (searchParams.get("trackingNumber") && searchParams.get("phone")) {
      fetchStatus(searchParams.get("trackingNumber")!, searchParams.get("phone")!);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleUploadExtra(e: React.FormEvent) {
    e.preventDefault();
    if (!extraFile) return;
    setUploadingExtra(true);
    try {
      const fd = new FormData();
      fd.append("trackingNumber", trackingNumber);
      fd.append("phone", phone);
      fd.append("document", extraFile);

      const res = await fetch("/api/registration/track", { method: "POST", body: fd });
      const json = await res.json();
      if (!res.ok) {
        alert(json.error);
      } else {
        setExtraFile(null);
        await fetchStatus();
      }
    } finally {
      setUploadingExtra(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4">
      <div className="max-w-3xl mx-auto space-y-6">
        <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-saliyah-green font-semibold hover:underline">
          <ArrowRight className="w-4 h-4" />
          العودة إلى الرئيسية
        </Link>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h1 className="text-xl font-bold text-slate-900 mb-4">متابعة طلب التسجيل وصندوق الرسائل النصية (SMS)</h1>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              fetchStatus();
            }}
            className="grid grid-cols-1 md:grid-cols-3 gap-3"
          >
            <input
              type="text"
              required
              placeholder="رقم المتابعة (مثال: PAS-2026-...)"
              value={trackingNumber}
              onChange={(e) => setTrackingNumber(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm outline-none focus:ring-2 focus:ring-saliyah-green"
            />
            <input
              type="text"
              required
              placeholder="رقم الجوال المسجل"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm outline-none focus:ring-2 focus:ring-saliyah-green"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-saliyah-green text-white font-bold rounded-lg text-sm hover:bg-saliyah-darkGreen flex items-center justify-center gap-2"
            >
              <Search className="w-4 h-4" />
              {loading ? "جاري البحث..." : "استعلام"}
            </button>
          </form>

          {error && <p className="mt-4 text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</p>}
        </div>

        {data && (
          <>
            {/* Status Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-4">
                <div>
                  <p className="text-xs text-slate-500">مقدم الطلب</p>
                  <h2 className="text-lg font-bold">{data.application.fullName}</h2>
                </div>

                <div>
                  {data.application.status === "UNDER_REVIEW" && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold">
                      <Clock className="w-4 h-4" /> قيد المراجعة لدى الجوازات
                    </span>
                  )}
                  {data.application.status === "DOCS_REQUIRED" && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-800 text-xs font-bold">
                      <AlertCircle className="w-4 h-4" /> مطلوب مستندات إضافية
                    </span>
                  )}
                  {data.application.status === "APPROVED" && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4" /> مقبول ومعتمد
                    </span>
                  )}
                  {data.application.status === "REJECTED" && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-100 text-red-800 text-xs font-bold">
                      <XCircle className="w-4 h-4" /> مرفوض
                    </span>
                  )}
                </div>
              </div>

              {data.application.reviewerNotes && (
                <div className="bg-slate-50 p-3 rounded-lg text-sm border">
                  <span className="font-bold">ملاحظات إدارة الجوازات: </span>
                  {data.application.reviewerNotes}
                </div>
              )}

              {data.application.issuedNationalId && (
                <div className="bg-emerald-50 border border-emerald-300 p-4 rounded-xl">
                  <p className="text-xs text-emerald-800 font-semibold">تم إصدار رقم الهوية / الإقامة الصالية:</p>
                  <p className="text-2xl font-mono font-bold text-saliyah-darkGreen mt-1">
                    {data.application.issuedNationalId}
                  </p>
                  <Link
                    href="/login"
                    className="inline-block mt-3 px-4 py-2 bg-saliyah-green text-white text-xs font-bold rounded-lg"
                  >
                    الانتقال لتسجيل الدخول
                  </Link>
                </div>
              )}

              {data.application.status === "DOCS_REQUIRED" && (
                <form onSubmit={handleUploadExtra} className="bg-orange-50 border border-orange-200 p-4 rounded-xl space-y-3">
                  <p className="text-sm font-bold text-orange-900">إرفاق المستند الإضافي المطلوب:</p>
                  <input
                    type="file"
                    required
                    onChange={(e) => setExtraFile(e.target.files?.[0] || null)}
                    className="block w-full text-sm"
                  />
                  <button
                    type="submit"
                    disabled={uploadingExtra}
                    className="px-4 py-2 bg-orange-600 text-white text-xs font-bold rounded-lg flex items-center gap-1.5"
                  >
                    <Upload className="w-4 h-4" />
                    {uploadingExtra ? "جاري الرفع..." : "رفع المستند وإعادة الإرسال"}
                  </button>
                </form>
              )}
            </div>

            {/* Simulated Mobile SMS Inbox */}
            <div className="bg-slate-900 text-white rounded-2xl shadow-md p-6">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
                <MessageSquare className="w-5 h-5 text-saliyah-gold" />
                <h3 className="font-bold">صندوق الرسائل النصية المحاكي (SMS Inbox)</h3>
              </div>
              <div className="space-y-3">
                {data.smsInbox.length === 0 && (
                  <p className="text-xs text-slate-400">لا توجد رسائل نصية لهذا الرقم حتى الآن.</p>
                )}
                {data.smsInbox.map((msg) => (
                  <div key={msg.id} className="bg-slate-800 rounded-xl p-4 border border-slate-700">
                    <div className="flex items-center justify-between text-xs text-saliyah-gold mb-1">
                      <span className="font-bold">{msg.senderName}</span>
                      <span className="text-slate-400">{new Date(msg.createdAt).toLocaleString("ar-SA")}</span>
                    </div>
                    <p className="text-sm text-slate-100 leading-relaxed">{msg.messageBody}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default function TrackPage() {
  return (
    <Suspense fallback={<div className="p-10 text-center">جاري التحميل...</div>}>
      <TrackContent />
    </Suspense>
  );
}
