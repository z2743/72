"use client";

import React, { useState } from "react";
import Link from "next/link";
import { UserPlus, Upload, ArrowRight, CheckCircle2, ShieldAlert } from "lucide-react";

export default function RegisterPage() {
  const [fullName, setFullName] = useState("");
  const [accountType, setAccountType] = useState<"CITIZEN" | "RESIDENT">("CITIZEN");
  const [submittedIdNumber, setSubmittedIdNumber] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [governorateId, setGovernorateId] = useState("gov-sajjadah");
  const [notes, setNotes] = useState("");
  const [documentFile, setDocumentFile] = useState<File | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ trackingNumber: string; message: string } | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (!documentFile) {
      setError("إرفاق صورة الهوية الوطنية أو الإقامة أو جواز السفر إلزامي لإتمام الطلب.");
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("fullName", fullName);
      formData.append("accountType", accountType);
      formData.append("submittedIdNumber", submittedIdNumber);
      formData.append("phone", phone);
      formData.append("email", email);
      formData.append("password", password);
      formData.append("governorateId", governorateId);
      formData.append("notes", notes);
      formData.append("document", documentFile);

      const res = await fetch("/api/registration", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "تعذر إرسال الطلب");
      } else {
        setResult({ trackingNumber: data.trackingNumber, message: data.message });
      }
    } catch {
      setError("حدث خطأ في الاتصال بالخادم.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4">
      <div className="max-w-2xl mx-auto">
        <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-saliyah-green font-semibold mb-6 hover:underline">
          <ArrowRight className="w-4 h-4" />
          العودة إلى الصفحة الرئيسية
        </Link>

        <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-6 md:p-8">
          <div className="flex items-center gap-3 mb-6 pb-4 border-b">
            <div className="w-11 h-11 rounded-xl bg-emerald-50 text-saliyah-green flex items-center justify-center">
              <UserPlus className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">تقديم طلب تسجيل وإصدار هوية صالية</h1>
              <p className="text-xs text-slate-500">يُراجع الطلب من قِبل إدارة الجوازات الصالية قبل تفعيل الحساب</p>
            </div>
          </div>

          {result ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6 text-center space-y-4">
              <CheckCircle2 className="w-12 h-12 text-saliyah-green mx-auto" />
              <h2 className="text-lg font-bold text-saliyah-darkGreen">{result.message}</h2>
              <div className="bg-white border border-emerald-300 rounded-lg p-4 inline-block">
                <p className="text-xs text-slate-500">رقم متابعة الطلب</p>
                <p className="text-2xl font-mono font-bold text-saliyah-green tracking-wider mt-1">
                  {result.trackingNumber}
                </p>
              </div>
              <p className="text-xs text-slate-600">
                تم إرسال إشعار تأكيد إلى صندوق الرسائل النصية الداخلي الخاص برقم جوالك ({phone}).
              </p>
              <div className="pt-2">
                <Link
                  href={`/track?trackingNumber=${result.trackingNumber}&phone=${encodeURIComponent(phone)}`}
                  className="inline-block px-6 py-2.5 bg-saliyah-green text-white font-bold rounded-xl text-sm hover:bg-saliyah-darkGreen"
                >
                  متابعة حالة الطلب وصندوق SMS
                </Link>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg text-sm flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold mb-1">نوع الحساب المطلوب *</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setAccountType("CITIZEN")}
                    className={`py-2.5 px-4 rounded-xl border text-sm font-bold transition ${
                      accountType === "CITIZEN"
                        ? "bg-saliyah-green text-white border-saliyah-green"
                        : "bg-white text-slate-700 border-slate-300"
                    }`}
                  >
                    مواطن صالي (هوية وطنية)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAccountType("RESIDENT")}
                    className={`py-2.5 px-4 rounded-xl border text-sm font-bold transition ${
                      accountType === "RESIDENT"
                        ? "bg-saliyah-green text-white border-saliyah-green"
                        : "bg-white text-slate-700 border-slate-300"
                    }`}
                  >
                    مقيم (رقم إقامة صالية)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">الاسم الكامل *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="الاسم الرباعي الكامل"
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-1">رقم الجوال (لاستقبال الإشعارات وOTP) *</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="أدخل رقم الجوال"
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">البريد الإلكتروني (اختياري)</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="example@..."
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-1">رقم الوثيقة الحالية / الجواز (إن وجد)</label>
                  <input
                    type="text"
                    value={submittedIdNumber}
                    onChange={(e) => setSubmittedIdNumber(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">المحافظة *</label>
                  <select
                    value={governorateId}
                    onChange={(e) => setGovernorateId(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg bg-white focus:ring-2 focus:ring-saliyah-green outline-none"
                  >
                    <option value="gov-sajjadah">محافظة السجادة (العاصمة)</option>
                    <option value="gov-mitjar">محافظة المتجار</option>
                    <option value="gov-aqar">محافظة عقار</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">كلمة المرور للحساب الجديد (8 خانات على الأقل) *</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">
                  صورة الهوية الوطنية أو الإقامة أو جواز السفر (إلزامي) *
                </label>
                <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-saliyah-green rounded-xl p-5 cursor-pointer bg-slate-50 transition">
                  <Upload className="w-7 h-7 text-saliyah-green mb-1" />
                  <span className="text-sm font-medium text-slate-700">
                    {documentFile ? documentFile.name : "اضغط لاختيار صورة الوثيقة أو ملف PDF (الحد الأقصى 5MB)"}
                  </span>
                  <input
                    type="file"
                    required
                    accept="image/jpeg,image/png,image/webp,application/pdf"
                    onChange={(e) => setDocumentFile(e.target.files?.[0] || null)}
                    className="hidden"
                  />
                </label>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">ملاحظات إضافية لإدارة الجوازات</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-saliyah-green hover:bg-saliyah-darkGreen text-white font-bold rounded-xl transition disabled:opacity-50"
              >
                {loading ? "جاري رفع الوثيقة وإرسال الطلب..." : "إرسال طلب التسجيل إلى إدارة الجوازات"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
