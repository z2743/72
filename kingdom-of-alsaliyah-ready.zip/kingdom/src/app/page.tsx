"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Shield,
  Building2,
  MapPin,
  UserPlus,
  LogIn,
  Search,
  Globe,
  Crown,
  AlertTriangle,
  FileCheck2,
  Landmark,
} from "lucide-react";

interface Governorate {
  id: string;
  nameAr: string;
  nameEn: string;
  capitalAr: string;
  descriptionAr: string;
  descriptionEn: string;
  governorName: string;
}

interface Entity {
  id: string;
  type: string;
  nameAr: string;
  nameEn: string;
  headName: string;
  headTitleAr: string;
  deputyName?: string;
  reportsDirectlyToKing: boolean;
}

export default function HomePage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const [initialized, setInitialized] = useState<boolean | null>(null);
  const [governorates, setGovernorates] = useState<Governorate[]>([]);
  const [entities, setEntities] = useState<Entity[]>([]);
  const [searchTerm, setSearchTerm] = useState("");

  // Initial Setup State (King Ziad first-time activation)
  const [kingNationalId, setKingNationalId] = useState("");
  const [kingPhone, setKingPhone] = useState("");
  const [kingEmail, setKingEmail] = useState("");
  const [kingPassword, setKingPassword] = useState("");
  const [setupLoading, setSetupLoading] = useState(false);
  const [setupError, setSetupError] = useState("");

  const isAr = lang === "ar";

  useEffect(() => {
    document.documentElement.dir = isAr ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [isAr, lang]);

  useEffect(() => {
    fetch("/api/setup")
      .then((r) => r.json())
      .then((data) => {
        setInitialized(Boolean(data.initialized));
        if (data.initialized) {
          fetch("/api/public/overview")
            .then((res) => res.json())
            .then((ov) => {
              setGovernorates(ov.governorates || []);
              setEntities(ov.entities || []);
            });
        }
      })
      .catch(() => setInitialized(false));
  }, []);

  async function handleInitialSetup(e: React.FormEvent) {
    e.preventDefault();
    setSetupLoading(true);
    setSetupError("");
    try {
      const res = await fetch("/api/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kingNationalId,
          kingPhone,
          kingEmail,
          password: kingPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setSetupError(data.error || "حدث خطأ أثناء التهيئة");
      } else {
        window.location.reload();
      }
    } catch {
      setSetupError("تعذر الاتصال بالخادم");
    } finally {
      setSetupLoading(false);
    }
  }

  const ministries = entities.filter(
    (e) =>
      e.type === "MINISTRY" &&
      (e.nameAr.includes(searchTerm) ||
        e.nameEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.headName.includes(searchTerm))
  );

  const authorities = entities.filter((e) => e.type !== "MINISTRY");

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* Official Top Sovereign Bar */}
      <header className="bg-saliyah-darkGreen text-white border-b-4 border-saliyah-gold shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/10 border border-saliyah-gold flex items-center justify-center">
              <Crown className="w-7 h-7 text-saliyah-gold" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold tracking-tight">
                {isAr ? "بوابة دولة المملكة العربية الصالية" : "Kingdom of Al-Saliyah Official Portal"}
              </h1>
              <p className="text-xs text-emerald-200">
                {isAr
                  ? "المنصة الحكومية الإلكترونية الموحدة — نظام خاص ومعتمد"
                  : "Unified Electronic Government Platform — Private Approved System"}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setLang(isAr ? "en" : "ar")}
              className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-sm font-medium flex items-center gap-1.5 transition"
            >
              <Globe className="w-4 h-4" />
              {isAr ? "English" : "العربية"}
            </button>

            <Link
              href="/track"
              className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-sm font-medium flex items-center gap-1.5 transition"
            >
              <FileCheck2 className="w-4 h-4" />
              {isAr ? "متابعة طلب وصندوق SMS" : "Track Request & SMS"}
            </Link>

            <Link
              href="/register"
              className="px-4 py-2 rounded-lg bg-saliyah-gold text-slate-900 hover:bg-amber-400 text-sm font-bold flex items-center gap-1.5 transition"
            >
              <UserPlus className="w-4 h-4" />
              {isAr ? "تقديم طلب تسجيل" : "Request Account"}
            </Link>

            <Link
              href="/login"
              className="px-4 py-2 rounded-lg bg-white text-saliyah-darkGreen hover:bg-emerald-50 text-sm font-bold flex items-center gap-1.5 transition"
            >
              <LogIn className="w-4 h-4" />
              {isAr ? "تسجيل الدخول" : "Sign In"}
            </Link>
          </div>
        </div>
      </header>

      {/* First-Time King Setup Gate (Only shown before initial setup is completed) */}
      {initialized === false && (
        <main className="max-w-2xl mx-auto my-12 px-4 w-full">
          <div className="bg-white rounded-2xl shadow-lg border border-emerald-200 p-8">
            <div className="flex items-center gap-3 mb-4 text-saliyah-green">
              <Crown className="w-8 h-8" />
              <div>
                <h2 className="text-xl font-bold">التأسيس الأولي لبوابة المملكة العربية الصالية</h2>
                <p className="text-sm text-slate-600">
                  إعداد حساب صاحب أعلى صلاحية في النظام: الملك زياد بندر سعد العمري
                </p>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-900 mb-6">
              سيقوم هذا الإعداد بإنشاء حساب الملك واعتماد المحافظات الثلاث (السجادة، المتجار، عقار) والتشكيل الوزاري المعتمد (35 وزارة) وهيئة الطيران المدني في قاعدة بيانات Cloudflare D1.
            </div>

            {setupError && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg text-sm mb-4">
                {setupError}
              </div>
            )}

            <form onSubmit={handleInitialSetup} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-1">الاسم الكامل واللقب الرسمي</label>
                <input
                  type="text"
                  disabled
                  value="زياد بندر سعد العمري — ملك المملكة العربية الصالية، وسيد السجادة، وحامي الديار الصالية"
                  className="w-full px-3 py-2 bg-slate-100 border rounded-lg text-sm text-slate-700"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">رقم الهوية الملكية المعتمد *</label>
                <input
                  type="text"
                  required
                  placeholder="أدخل رقم الهوية الملكية لتسجيل الدخول به"
                  value={kingNationalId}
                  onChange={(e) => setKingNationalId(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-1">رقم الجوال (لاستقبال OTP الداخلي) *</label>
                  <input
                    type="text"
                    required
                    placeholder="أدخل رقم الجوال"
                    value={kingPhone}
                    onChange={(e) => setKingPhone(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">البريد الإلكتروني (اختياري)</label>
                  <input
                    type="email"
                    placeholder="king@..."
                    value={kingEmail}
                    onChange={(e) => setKingEmail(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">كلمة المرور الملكية (8 خانات فأكثر) *</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={kingPassword}
                  onChange={(e) => setKingPassword(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-saliyah-green outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={setupLoading}
                className="w-full py-3 bg-saliyah-green hover:bg-saliyah-darkGreen text-white font-bold rounded-xl transition disabled:opacity-50"
              >
                {setupLoading ? "جاري تأسيس الدولة واعتماد قاعدة البيانات..." : "اعتماد التأسيس وإنشاء حساب الملك"}
              </button>
            </form>
          </div>
        </main>
      )}

      {/* Main Public Government Portal */}
      {initialized === true && (
        <main className="flex-1 max-w-7xl mx-auto px-4 py-8 w-full space-y-10">
          {/* Sovereign Leadership Banner */}
          <section className="bg-gradient-to-l from-saliyah-darkGreen to-saliyah-green text-white rounded-2xl p-6 md:p-8 shadow-md">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div>
                <span className="inline-block px-3 py-1 rounded-full bg-white/15 text-xs font-semibold mb-3">
                  {isAr ? "العاصمة: مدينة السجادة • 3 محافظات • 35 وزارة" : "Capital: Al-Sajjadah • 3 Governorates • 35 Ministries"}
                </span>
                <h2 className="text-2xl md:text-3xl font-bold mb-3">
                  {isAr
                    ? "مرحباً بكم في البوابة الرسمية للمملكة العربية الصالية"
                    : "Welcome to the Official Portal of the Kingdom of Al-Saliyah"}
                </h2>
                <p className="text-emerald-100 text-sm leading-relaxed">
                  {isAr
                    ? "منصة حكومية إلكترونية متكاملة لإدارة الهوية الوطنية، الجوازات، الوزارات، المحافظات، الديوان الملكي الصالي، والخدمات الرقمية المعتمدة."
                    : "Integrated electronic government platform for National ID, Passports, Ministries, Governorates, Al-Saliyah Royal Court, and official services."}
                </p>
              </div>

              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-5 space-y-3">
                <div className="border-b border-white/15 pb-3">
                  <p className="text-xs text-saliyah-gold font-semibold">
                    {isAr ? "ملك المملكة العربية الصالية، وسيد السجادة، وحامي الديار الصالية" : "King of Al-Saliyah"}
                  </p>
                  <p className="text-lg font-bold">زياد بندر سعد العمري</p>
                </div>
                <div>
                  <p className="text-xs text-emerald-200 font-semibold">
                    {isAr ? "ولي العهد ورئيس مجلس الوزراء" : "Crown Prince and Prime Minister"}
                  </p>
                  <p className="text-base font-bold">قطبي بن زياد بن بندر العمري</p>
                </div>
              </div>
            </div>
          </section>

          {/* Governorates Section */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-6 h-6 text-saliyah-green" />
              <h3 className="text-xl font-bold text-slate-900">
                {isAr ? "محافظات المملكة العربية الصالية" : "Governorates of the Kingdom"}
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {governorates.map((gov) => (
                <div key={gov.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:border-saliyah-green transition">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-bold text-lg text-saliyah-darkGreen">
                      {isAr ? gov.nameAr : gov.nameEn}
                    </h4>
                    <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 text-saliyah-green font-semibold">
                      {gov.capitalAr}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                    {isAr ? gov.descriptionAr : gov.descriptionEn}
                  </p>
                  <div className="pt-3 border-t border-slate-100 text-xs">
                    <span className="text-slate-500">{isAr ? "المحافظ: " : "Governor: "}</span>
                    <span className="font-bold text-slate-800">{gov.governorName}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Sovereign Authorities & Direct King Entities */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <Landmark className="w-6 h-6 text-saliyah-green" />
              <h3 className="text-xl font-bold text-slate-900">
                {isAr ? "الهيئات السيادية والأجهزة المرتبطة بالملك ومجلس الوزراء" : "Sovereign Authorities"}
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {authorities.map((auth) => (
                <div key={auth.id} className="bg-white rounded-xl border border-amber-200 p-4 shadow-sm">
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-800">
                    {auth.reportsDirectlyToKing ? "ارتباط مباشر بالملك" : "جهة سيادية"}
                  </span>
                  <h4 className="font-bold text-slate-900 mt-2">{isAr ? auth.nameAr : auth.nameEn}</h4>
                  <p className="text-xs text-slate-600 mt-1">{auth.headName}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Ministries Directory (35 Ministries) */}
          <section>
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-2">
                <Building2 className="w-6 h-6 text-saliyah-green" />
                <h3 className="text-xl font-bold text-slate-900">
                  {isAr ? `التشكيل الوزاري المعتمد (${ministries.length} وزارة)` : `Approved Ministries (${ministries.length})`}
                </h3>
              </div>
              <div className="relative w-full md:w-72">
                <Search className="w-4 h-4 absolute top-3 right-3 text-slate-400" />
                <input
                  type="text"
                  placeholder={isAr ? "ابحث باسم الوزارة أو الوزير..." : "Search ministry or minister..."}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pr-9 pl-3 py-2 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-saliyah-green outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {ministries.map((min) => (
                <div key={min.id} className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
                  <h4 className="font-bold text-slate-900">{isAr ? min.nameAr : min.nameEn}</h4>
                  <p className="text-xs text-saliyah-green font-semibold mt-1">{min.headName}</p>
                  {min.deputyName && (
                    <p className="text-xs text-slate-500 mt-1">
                      نائب الوزير: <span className="font-medium text-slate-700">{min.deputyName}</span>
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        </main>
      )}

      {/* Official Footer */}
      <footer className="bg-slate-900 text-slate-300 py-6 mt-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-saliyah-gold" />
            <span>بوابة دولة المملكة العربية الصالية — Kingdom of Al-Saliyah Official Portal</span>
          </div>
          <span>نظام محاكاة حكومي خاص ومستقل • يعمل على شبكة Cloudflare السحابية 24/7</span>
        </div>
      </footer>
    </div>
  );
}
