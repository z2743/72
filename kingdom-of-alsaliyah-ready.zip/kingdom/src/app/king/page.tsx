"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Crown, Users, Building2, Settings, History, FileCheck, ShieldAlert, LogOut } from "lucide-react";
import { useRouter } from "next/navigation";

export default function KingDashboardPage() {
  const router = useRouter();
  const [data, setData] = useState<{
    stats: Record<string, number>;
    users: Array<{
      id: string;
      nationalId: string;
      fullName: string;
      accountType: string;
      phone: string;
      status: string;
      officialTitle?: string;
    }>;
    settings: Array<{ key: string; value: string; description: string }>;
    recentAuditLogs: Array<{
      id: string;
      actorName: string;
      actorRole: string;
      actionType: string;
      targetId: string;
      outcome: string;
      createdAt: string;
    }>;
  } | null>(null);
  const [error, setError] = useState("");
  const [settingValues, setSettingValues] = useState<Record<string, string>>({});
  const [roleUserId, setRoleUserId] = useState("");
  const [roleCode, setRoleCode] = useState("PASSPORT_OFFICER");
  const [roleTitle, setRoleTitle] = useState("موظف إدارة الجوازات الصالية");

  async function loadKingOverview() {
    const res = await fetch("/api/king/overview");
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "غير مصرح");
    } else {
      setData(json);
      const map: Record<string, string> = {};
      json.settings.forEach((s: { key: string; value: string }) => {
        map[s.key] = s.value;
      });
      setSettingValues(map);
    }
  }

  useEffect(() => {
    loadKingOverview();
  }, []);

  async function handleSaveSetting(key: string) {
    const res = await fetch("/api/king/overview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "UPDATE_SETTING", key, value: settingValues[key] }),
    });
    const json = await res.json();
    alert(json.message || json.error);
    await loadKingOverview();
  }

  async function handleGrantRole(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/king/overview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "GRANT_ROLE",
        targetUserId: roleUserId,
        roleCode,
        entityId: "min-interior",
        positionTitleAr: roleTitle,
      }),
    });
    const json = await res.json();
    alert(json.message || json.error);
    await loadKingOverview();
  }

  async function handleLogout() {
    await fetch("/api/auth/login", { method: "DELETE" });
    router.push("/login");
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-red-50 border border-red-200 text-red-700 p-6 rounded-2xl max-w-md text-center space-y-3">
          <ShieldAlert className="w-10 h-10 mx-auto" />
          <p className="font-bold">{error}</p>
          <Link href="/login" className="inline-block px-4 py-2 bg-slate-900 text-white rounded-lg text-xs">
            تسجيل الدخول بحساب الملك
          </Link>
        </div>
      </div>
    );
  }

  if (!data) {
    return <div className="p-10 text-center text-slate-600">جاري تحميل لوحة الملك وإدارة الدولة...</div>;
  }

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Royal Header */}
      <header className="bg-slate-900 text-white border-b-4 border-saliyah-gold px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Crown className="w-8 h-8 text-saliyah-gold" />
            <div>
              <h1 className="text-xl font-bold">لوحة الملك وإدارة الدولة — المملكة العربية الصالية</h1>
              <p className="text-xs text-saliyah-gold">ملك المملكة العربية الصالية، وسيد السجادة، وحامي الديار الصالية</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/passports"
              className="px-4 py-2 bg-saliyah-green hover:bg-saliyah-darkGreen rounded-xl text-xs font-bold flex items-center gap-1.5"
            >
              <FileCheck className="w-4 h-4" />
              إدارة الجوازات ({data.stats.pendingPassportApps})
            </Link>
            <button
              onClick={handleLogout}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-xs flex items-center gap-1"
            >
              <LogOut className="w-4 h-4" /> خروج
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Live State Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-white p-4 rounded-xl border shadow-sm">
            <p className="text-xs text-slate-500">المواطنون الصاليون</p>
            <p className="text-2xl font-bold text-saliyah-green mt-1">{data.stats.citizensCount}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border shadow-sm">
            <p className="text-xs text-slate-500">المقيمون المعتمدون</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{data.stats.residentsCount}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border shadow-sm">
            <p className="text-xs text-slate-500">طلبات الجوازات المعلقة</p>
            <p className="text-2xl font-bold text-amber-600 mt-1">{data.stats.pendingPassportApps}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border shadow-sm">
            <p className="text-xs text-slate-500">الوزارات المعتمدة</p>
            <p className="text-2xl font-bold text-saliyah-darkGreen mt-1">{data.stats.ministriesCount}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border shadow-sm">
            <p className="text-xs text-slate-500">المحافظات</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{data.stats.governoratesCount}</p>
          </div>
        </div>

        {/* Configurable System Settings (STC / Zain Prefixes & Mail Domain) */}
        <section className="bg-white rounded-2xl border p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b pb-3">
            <Settings className="w-5 h-5 text-saliyah-green" />
            <h2 className="font-bold text-lg">إعدادات المملكة القابلة للتعديل (بادئات STC وزين ونطاق البريد)</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {data.settings.map((s) => (
              <div key={s.key} className="border rounded-xl p-4 bg-slate-50 space-y-2">
                <p className="text-xs font-bold text-slate-700">{s.description}</p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={settingValues[s.key] || ""}
                    onChange={(e) => setSettingValues({ ...settingValues, [s.key]: e.target.value })}
                    className="flex-1 px-3 py-1.5 bg-white border rounded-lg text-sm font-mono"
                  />
                  <button
                    onClick={() => handleSaveSetting(s.key)}
                    className="px-4 py-1.5 bg-saliyah-green text-white text-xs font-bold rounded-lg"
                  >
                    حفظ
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Royal Appointments & Passport Officer Role Assignment */}
        <section className="bg-white rounded-2xl border p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b pb-3">
            <Users className="w-5 h-5 text-saliyah-green" />
            <h2 className="font-bold text-lg">الأوامر الملكية: تعيين المسؤولين وصلاحيات موظفي الجوازات والوزارات</h2>
          </div>
          <form onSubmit={handleGrantRole} className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <select
              required
              value={roleUserId}
              onChange={(e) => setRoleUserId(e.target.value)}
              className="px-3 py-2 border rounded-xl text-sm bg-white"
            >
              <option value="">اختر الحساب المعتمد...</option>
              {data.users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.fullName} ({u.nationalId})
                </option>
              ))}
            </select>

            <select
              value={roleCode}
              onChange={(e) => setRoleCode(e.target.value)}
              className="px-3 py-2 border rounded-xl text-sm bg-white"
            >
              <option value="PASSPORT_OFFICER">موظف إدارة الجوازات</option>
              <option value="MINISTER">وزير</option>
              <option value="GOVERNOR">محافظ</option>
              <option value="ROYAL_COURT_STAFF">موظف الديوان الملكي</option>
              <option value="AUDIT_STAFF">مراقب ديوان المحاسبة</option>
            </select>

            <input
              type="text"
              required
              value={roleTitle}
              onChange={(e) => setRoleTitle(e.target.value)}
              placeholder="المسمى الوظيفي الرسمي"
              className="px-3 py-2 border rounded-xl text-sm"
            />

            <button
              type="submit"
              className="px-4 py-2 bg-saliyah-darkGreen text-white font-bold rounded-xl text-sm"
            >
              اعتماد الصلاحية بأمر ملكي
            </button>
          </form>
        </section>

        {/* Central Audit Log */}
        <section className="bg-white rounded-2xl border p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b pb-3">
            <History className="w-5 h-5 text-saliyah-green" />
            <h2 className="font-bold text-lg">سجل التدقيق المركزي غير القابل للتلاعب (آخر 30 عملية)</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-right">
              <thead className="bg-slate-100 text-slate-700">
                <tr>
                  <th className="p-2.5">المنفذ</th>
                  <th className="p-2.5">الدور</th>
                  <th className="p-2.5">العملية</th>
                  <th className="p-2.5">الهدف</th>
                  <th className="p-2.5">النتيجة</th>
                  <th className="p-2.5">الوقت</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {data.recentAuditLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="p-2.5 font-semibold">{log.actorName}</td>
                    <td className="p-2.5">{log.actorRole}</td>
                    <td className="p-2.5 font-mono">{log.actionType}</td>
                    <td className="p-2.5 font-mono">{log.targetId}</td>
                    <td className="p-2.5">
                      <span
                        className={`px-2 py-0.5 rounded font-bold ${
                          log.outcome === "SUCCESS" ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"
                        }`}
                      >
                        {log.outcome}
                      </span>
                    </td>
                    <td className="p-2.5 text-slate-500">{new Date(log.createdAt).toLocaleString("ar-SA")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
