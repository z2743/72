import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { getDb } from "@/lib/cloudflare";
import { users, civilRecords, userRoles, smsMessages, royalCourtRequests, incidentReports } from "@/db/schema";
import { getSession } from "@/lib/session";

export const runtime = "edge";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }

  const db = getDb();
  const [user, civil, roles, messages, requests, reports] = await Promise.all([
    db.query.users.findFirst({ where: eq(users.id, session.userId) }),
    db.query.civilRecords.findFirst({ where: eq(civilRecords.userId, session.userId) }),
    db.query.userRoles.findMany({ where: eq(userRoles.userId, session.userId) }),
    db.query.smsMessages.findMany({
      where: eq(smsMessages.recipientPhone, (await db.query.users.findFirst({ where: eq(users.id, session.userId) }))?.phone || ""),
      orderBy: [desc(smsMessages.createdAt)],
    }),
    db.query.royalCourtRequests.findMany({
      where: eq(royalCourtRequests.applicantId, session.userId),
      orderBy: [desc(royalCourtRequests.createdAt)],
    }),
    db.query.incidentReports.findMany({
      where: eq(incidentReports.reporterId, session.userId),
      orderBy: [desc(incidentReports.createdAt)],
    }),
  ]);

  if (!user) {
    return NextResponse.json({ error: "الحساب غير موجود" }, { status: 404 });
  }

  return NextResponse.json({
    profile: {
      id: user.id,
      nationalId: user.nationalId,
      fullName: user.fullName,
      accountType: user.accountType,
      phone: user.phone,
      email: user.email,
      status: user.status,
      isSupremeKing: user.isSupremeKing,
      officialTitle: user.officialTitle,
    },
    civilRecord: civil,
    roles,
    smsInbox: messages,
    royalCourtRequests: requests,
    incidentReports: reports,
  });
}
