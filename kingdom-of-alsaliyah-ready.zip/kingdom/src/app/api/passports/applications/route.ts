import { NextResponse } from "next/server";
import { eq, and, desc } from "drizzle-orm";
import { getDb } from "@/lib/cloudflare";
import {
  registrationApplications,
  attachments,
  users,
  civilRecords,
  userRoles,
  smsMessages,
} from "@/db/schema";
import { getSession } from "@/lib/session";
import { generateCandidateNationalId } from "@/lib/crypto";
import { logAuditEvent } from "@/lib/audit";

export const runtime = "edge";

async function verifyPassportAuthority(userId: string, isSupremeKing: boolean) {
  if (isSupremeKing) return true;
  const db = getDb();
  const roles = await db.query.userRoles.findMany({
    where: and(eq(userRoles.userId, userId), eq(userRoles.isActive, true)),
  });
  return roles.some(
    (r) =>
      r.roleCode === "PASSPORT_OFFICER" ||
      (r.roleCode === "MINISTER" && r.entityId === "min-interior") ||
      (r.roleCode === "DEPUTY_MINISTER" && r.entityId === "min-interior")
  );
}

// GET: List all registration applications for authorized Passport Officers / Minister of Interior / King
export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "غير مصرح. يرجى تسجيل الدخول." }, { status: 401 });
  }

  const authorized = await verifyPassportAuthority(session.userId, session.isSupremeKing);
  if (!authorized) {
    await logAuditEvent({
      actorUserId: session.userId,
      actorName: session.fullName,
      actorRole: session.accountType,
      actionType: "UNAUTHORIZED_ACCESS_ATTEMPT",
      targetType: "PASSPORTS_DASHBOARD",
      targetId: "ALL",
      outcome: "DENIED",
    });
    return NextResponse.json({ error: "ليس لديك صلاحية الوصول إلى لوحة إدارة الجوازات." }, { status: 403 });
  }

  const db = getDb();
  const apps = await db.query.registrationApplications.findMany({
    orderBy: [desc(registrationApplications.createdAt)],
  });

  const enrichedApps = await Promise.all(
    apps.map(async (app) => {
      const docs = await db.query.attachments.findMany({
        where: eq(attachments.ownerId, app.id),
      });
      return {
        id: app.id,
        trackingNumber: app.trackingNumber,
        fullName: app.fullName,
        accountType: app.accountType,
        submittedIdNumber: app.submittedIdNumber,
        phone: app.phone,
        email: app.email,
        governorateId: app.governorateId,
        notes: app.notes,
        status: app.status,
        reviewerNotes: app.reviewerNotes,
        reviewedBy: app.reviewedBy,
        reviewedAt: app.reviewedAt,
        createdAt: app.createdAt,
        attachments: docs.map((d) => ({
          id: d.id,
          fileName: d.fileName,
          fileType: d.fileType,
          ownerType: d.ownerType,
          createdAt: d.createdAt,
        })),
      };
    })
  );

  return NextResponse.json({ applications: enrichedApps });
}

// POST: Process Passport Decision (APPROVE | REJECT | REQUEST_DOCS)
export async function POST(req: Request) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "يرجى تسجيل الدخول." }, { status: 401 });
  }

  const authorized = await verifyPassportAuthority(session.userId, session.isSupremeKing);
  if (!authorized) {
    return NextResponse.json({ error: "غير مخول باتخاذ قرارات الجوازات." }, { status: 403 });
  }

  try {
    const { applicationId, decision, reviewerNotes } = await req.json();
    if (!applicationId || !["APPROVE", "REJECT", "REQUEST_DOCS"].includes(decision)) {
      return NextResponse.json({ error: "بيانات القرار غير صالحة." }, { status: 400 });
    }

    const db = getDb();
    const app = await db.query.registrationApplications.findFirst({
      where: eq(registrationApplications.id, applicationId),
    });

    if (!app) {
      return NextResponse.json({ error: "الطلب غير موجود." }, { status: 404 });
    }

    if (app.status === "APPROVED") {
      return NextResponse.json({ error: "تم اعتماد هذا الطلب مسبقاً." }, { status: 400 });
    }

    const now = new Date();

    // Case 1: Request Additional Documents
    if (decision === "REQUEST_DOCS") {
      if (!reviewerNotes?.trim()) {
        return NextResponse.json({ error: "يجب تحديد المستندات الإضافية المطلوبة في الملاحظات." }, { status: 400 });
      }

      await db.update(registrationApplications)
        .set({
          status: "DOCS_REQUIRED",
          reviewerNotes: reviewerNotes.trim(),
          reviewedBy: session.userId,
          reviewedAt: now,
          updatedAt: now,
        })
        .where(eq(registrationApplications.id, app.id));

      await db.insert(smsMessages).values({
        id: crypto.randomUUID(),
        recipientPhone: app.phone,
        senderName: "إدارة الجوازات الصالية",
        messageBody: `مطلوب مستندات إضافية لطلب التسجيل (${app.trackingNumber}): ${reviewerNotes.trim()}`,
        isRead: false,
        createdAt: now,
      });

      await logAuditEvent({
        actorUserId: session.userId,
        actorName: session.fullName,
        actorRole: session.isSupremeKing ? "KING" : "PASSPORT_OFFICER",
        entityId: "min-interior",
        actionType: "REQUEST_ADDITIONAL_DOCS",
        targetType: "REGISTRATION_APPLICATION",
        targetId: app.trackingNumber,
        previousData: { status: app.status },
        newData: { status: "DOCS_REQUIRED", reviewerNotes },
        reason: reviewerNotes,
        outcome: "SUCCESS",
      });

      return NextResponse.json({ success: true, message: "تم إرسال طلب المستندات الإضافية للمتقدم." });
    }

    // Case 2: Reject Application
    if (decision === "REJECT") {
      if (!reviewerNotes?.trim()) {
        return NextResponse.json({ error: "يجب ذكر سبب الرفض بوضوح." }, { status: 400 });
      }

      await db.update(registrationApplications)
        .set({
          status: "REJECTED",
          reviewerNotes: reviewerNotes.trim(),
          reviewedBy: session.userId,
          reviewedAt: now,
          updatedAt: now,
        })
        .where(eq(registrationApplications.id, app.id));

      await db.insert(smsMessages).values({
        id: crypto.randomUUID(),
        recipientPhone: app.phone,
        senderName: "إدارة الجوازات الصالية",
        messageBody: `نأسف لإبلاغكم برفض طلب التسجيل (${app.trackingNumber}). السبب: ${reviewerNotes.trim()}`,
        isRead: false,
        createdAt: now,
      });

      await logAuditEvent({
        actorUserId: session.userId,
        actorName: session.fullName,
        actorRole: session.isSupremeKing ? "KING" : "PASSPORT_OFFICER",
        entityId: "min-interior",
        actionType: "REJECT_REGISTRATION",
        targetType: "REGISTRATION_APPLICATION",
        targetId: app.trackingNumber,
        previousData: { status: app.status },
        newData: { status: "REJECTED", reviewerNotes },
        reason: reviewerNotes,
        outcome: "SUCCESS",
      });

      return NextResponse.json({ success: true, message: "تم رفض الطلب وإشعار المتقدم." });
    }

    // Case 3: Approve Application -> Collision-safe National ID generation + User Account + Civil Record
    let generatedNationalId = "";
    let newUserId = crypto.randomUUID();
    let inserted = false;

    for (let attempt = 0; attempt < 10; attempt++) {
      const candidate = generateCandidateNationalId(app.accountType as "CITIZEN" | "RESIDENT");
      try {
        await db.insert(users).values({
          id: newUserId,
          nationalId: candidate,
          accountType: app.accountType,
          fullName: app.fullName,
          phone: app.phone,
          email: app.email,
          passwordHash: app.passwordHash,
          passwordSalt: app.passwordSalt,
          status: "ACTIVE",
          isSupremeKing: false,
          createdAt: now,
          updatedAt: now,
        });
        generatedNationalId = candidate;
        inserted = true;
        break;
      } catch {
        // Collision on unique national_id -> retry safely
      }
    }

    if (!inserted || !generatedNationalId) {
      return NextResponse.json({ error: "تعذر توليد رقم هوية فريد، يرجى المحاولة مرة أخرى." }, { status: 500 });
    }

    // Create Civil Record (السجل المدني)
    await db.insert(civilRecords).values({
      id: crypto.randomUUID(),
      userId: newUserId,
      nationalId: generatedNationalId,
      recordType: app.accountType,
      governorateId: app.governorateId,
      citizenshipStatus: "ACTIVE",
      createdAt: now,
    });

    // Grant default Citizen or Resident role
    await db.insert(userRoles).values({
      id: crypto.randomUUID(),
      userId: newUserId,
      roleCode: app.accountType,
      positionTitleAr: app.accountType === "CITIZEN" ? "مواطن صالي" : "مقيم في المملكة الصالية",
      permissionsJson: JSON.stringify(["PORTAL_SERVICES", "ROYAL_COURT_SUBMIT", "REPORTS_SUBMIT"]),
      isActive: true,
      grantedBy: session.userId,
      createdAt: now,
    });

    // Mark Application Approved
    await db.update(registrationApplications)
      .set({
        status: "APPROVED",
        reviewerNotes: reviewerNotes?.trim() || "تم التحقق من الوثائق واعتماد الهوية الصالية.",
        reviewedBy: session.userId,
        reviewedAt: now,
        approvedUserId: newUserId,
        updatedAt: now,
      })
      .where(eq(registrationApplications.id, app.id));

    // Send simulated SMS with new National ID
    const idLabel = app.accountType === "CITIZEN" ? "الهوية الوطنية الصالية" : "رقم الإقامة الصالية";
    await db.insert(smsMessages).values({
      id: crypto.randomUUID(),
      recipientPhone: app.phone,
      recipientUserId: newUserId,
      senderName: "إدارة الجوازات الصالية",
      messageBody: `مبارك! تم اعتماد طلبكم (${app.trackingNumber}). ${idLabel}: ${generatedNationalId}. يمكنك الآن تسجيل الدخول إلى بوابة المملكة العربية الصالية.`,
      isRead: false,
      createdAt: now,
    });

    await logAuditEvent({
      actorUserId: session.userId,
      actorName: session.fullName,
      actorRole: session.isSupremeKing ? "KING" : "PASSPORT_OFFICER",
      entityId: "min-interior",
      actionType: "APPROVE_REGISTRATION_AND_ISSUE_ID",
      targetType: "USER_IDENTITY",
      targetId: generatedNationalId,
      previousData: { trackingNumber: app.trackingNumber, status: app.status },
      newData: { userId: newUserId, nationalId: generatedNationalId, accountType: app.accountType },
      reason: reviewerNotes || "اعتماد طلب التسجيل وإصدار الهوية",
      outcome: "SUCCESS",
    });

    return NextResponse.json({
      success: true,
      nationalId: generatedNationalId,
      message: `تم قبول الطلب وإصدار ${idLabel} بنجاح: ${generatedNationalId}`,
    });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: "حدث خطأ أثناء معالجة الطلب: " + (err instanceof Error ? err.message : String(err)) },
      { status: 500 }
    );
  }
}
