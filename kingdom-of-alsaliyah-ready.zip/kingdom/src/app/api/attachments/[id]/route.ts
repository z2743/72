import { NextResponse } from "next/server";
import { eq, and } from "drizzle-orm";
import { getDb, getBucket } from "@/lib/cloudflare";
import { attachments, userRoles } from "@/db/schema";
import { getSession } from "@/lib/session";

export const runtime = "edge";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }

  const db = getDb();
  const roles = await db.query.userRoles.findMany({
    where: and(eq(userRoles.userId, session.userId), eq(userRoles.isActive, true)),
  });

  const canViewDocs =
    session.isSupremeKing ||
    roles.some(
      (r) =>
        r.roleCode === "PASSPORT_OFFICER" ||
        (r.roleCode === "MINISTER" && r.entityId === "min-interior") ||
        r.roleCode === "ROYAL_COURT_STAFF"
    );

  if (!canViewDocs) {
    return NextResponse.json({ error: "ليس لديك صلاحية الاطلاع على الوثائق المرفقة." }, { status: 403 });
  }

  const doc = await db.query.attachments.findFirst({
    where: eq(attachments.id, params.id),
  });

  if (!doc) {
    return NextResponse.json({ error: "الملف غير موجود." }, { status: 404 });
  }

  const bucket = getBucket();
  const object = await bucket.get(doc.r2Key);
  if (!object) {
    return NextResponse.json({ error: "تعذر استرجاع الملف من التخزين السحابي." }, { status: 404 });
  }

  return new Response(object.body, {
    headers: {
      "Content-Type": doc.fileType,
      "Content-Disposition": `inline; filename="${encodeURIComponent(doc.fileName)}"`,
    },
  });
}
