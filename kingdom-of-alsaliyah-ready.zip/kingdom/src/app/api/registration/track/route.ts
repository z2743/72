import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { getDb, getBucket } from "@/lib/cloudflare";
import { registrationApplications, attachments, smsMessages, users } from "@/db/schema";
import { logAuditEvent } from "@/lib/audit";

export const runtime = "edge";

// GET: Check application status & view simulated SMS messages for the applicant's phone
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const trackingNumber = searchParams.get("trackingNumber")?.trim();
  const phone = searchParams.get("phone")?.trim();

  if (!trackingNumber || !phone) {
    return NextResponse.json({ error: "يرجى إدخال رقم المتابعة ورقم الجوال المسجل." }, { status: 400 });
  }

  const db = getDb();
  const app = await db.query.registrationApplications.findFirst({
    where: eq(registrationApplications.trackingNumber, trackingNumber),
  });

  if (!app || app.phone !== phone) {
    return NextResponse.json({ error: "بيانات المتابعة غير صحيحة أو لا يوجد طلب مطابق." }, { status: 404 });
  }

  const appDocs = await db.query.attachments.findMany({
    where: eq(attachments.ownerId, app.id),
  });

  const messages = await db.query.smsMessages.findMany({
    where: eq(smsMessages.recipientPhone, phone),
  });

  let issuedNationalId: string | null = null;
  if (app.approvedUserId) {
    const approvedUser = await db.query.users.findFirst({
      where: eq(users.id, app.approvedUserId),
    });
    issuedNationalId = approvedUser?.nationalId || null;
  }

  return NextResponse.json({
    application: {
      id: app.id,
      trackingNumber: app.trackingNumber,
      fullName: app.fullName,
      accountType: app.accountType,
      status: app.status,
      reviewerNotes: app.reviewerNotes,
      issuedNationalId,
      createdAt: app.createdAt,
      updatedAt: app.updatedAt,
    },
    documentsCount: appDocs.length,
    smsInbox: messages.sort((a, b) => Number(b.createdAt) - Number(a.createdAt)),
  });
}

// POST: Upload additional requested documents by applicant
export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const trackingNumber = String(formData.get("trackingNumber") || "").trim();
    const phone = String(formData.get("phone") || "").trim();
    const extraDoc = formData.get("document") as File | null;

    if (!trackingNumber || !phone || !extraDoc || extraDoc.size === 0) {
      return NextResponse.json({ error: "يرجى إرفاق المستند الإضافي المطلوب." }, { status: 400 });
    }

    const db = getDb();
    const app = await db.query.registrationApplications.findFirst({
      where: eq(registrationApplications.trackingNumber, trackingNumber),
    });

    if (!app || app.phone !== phone) {
      return NextResponse.json({ error: "الطلب غير موجود." }, { status: 404 });
    }

    if (app.status !== "DOCS_REQUIRED") {
      return NextResponse.json({ error: "هذا الطلب لا ينتظر مستندات إضافية حالياً." }, { status: 400 });
    }

    const bucket = getBucket();
    const fileExt = extraDoc.name.split(".").pop() || "bin";
    const r2Key = `registrations/${app.id}/extra-${crypto.randomUUID()}.${fileExt}`;
    await bucket.put(r2Key, await extraDoc.arrayBuffer(), {
      httpMetadata: { contentType: extraDoc.type },
    });

    const now = new Date();
    await db.insert(attachments).values({
      id: crypto.randomUUID(),
      ownerType: "ADDITIONAL_DOC",
      ownerId: app.id,
      fileName: extraDoc.name,
      fileType: extraDoc.type,
      fileSize: extraDoc.size,
      r2Key,
      uploadedBy: app.fullName,
      createdAt: now,
    });

    await db.update(registrationApplications)
      .set({ status: "UNDER_REVIEW", updatedAt: now })
      .where(eq(registrationApplications.id, app.id));

    await db.insert(smsMessages).values({
      id: crypto.randomUUID(),
      recipientPhone: phone,
      senderName: "إدارة الجوازات الصالية",
      messageBody: `تم استلام المستندات الإضافية للطلب (${trackingNumber}) وإعادة الطلب للمراجعة.`,
      isRead: false,
      createdAt: now,
    });

    await logAuditEvent({
      actorName: app.fullName,
      actorRole: "VISITOR_APPLICANT",
      entityId: "min-interior",
      actionType: "UPLOAD_ADDITIONAL_DOCUMENT",
      targetType: "REGISTRATION_APPLICATION",
      targetId: trackingNumber,
      newData: { fileName: extraDoc.name },
      outcome: "SUCCESS",
    });

    return NextResponse.json({
      success: true,
      message: "تم رفع المستند الإضافي وإعادة الطلب للمراجعة بنجاح.",
    });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: "خطأ أثناء رفع المستند: " + (err instanceof Error ? err.message : String(err)) },
      { status: 500 }
    );
  }
}
