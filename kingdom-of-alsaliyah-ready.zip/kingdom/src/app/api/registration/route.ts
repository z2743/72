import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { getDb, getBucket } from "@/lib/cloudflare";
import { registrationApplications, attachments, users, smsMessages } from "@/db/schema";
import { hashPassword, generateTrackingNumber } from "@/lib/crypto";
import { logAuditEvent } from "@/lib/audit";

export const runtime = "edge";

// POST: Submit new Citizen or Resident registration request with mandatory ID/Passport photo
export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const fullName = String(formData.get("fullName") || "").trim();
    const accountType = String(formData.get("accountType") || "").trim(); // CITIZEN | RESIDENT
    const submittedIdNumber = String(formData.get("submittedIdNumber") || "").trim();
    const phone = String(formData.get("phone") || "").trim();
    const email = String(formData.get("email") || "").trim();
    const password = String(formData.get("password") || "");
    const governorateId = String(formData.get("governorateId") || "gov-sajjadah").trim();
    const notes = String(formData.get("notes") || "").trim();
    const documentFile = formData.get("document") as File | null;

    if (!fullName || !["CITIZEN", "RESIDENT"].includes(accountType) || !phone || !password) {
      return NextResponse.json({ error: "جميع الحقول الأساسية مطلوبة (الاسم، نوع الحساب، الجوال، كلمة المرور)." }, { status: 400 });
    }

    if (password.length < 8) {
      return NextResponse.json({ error: "كلمة المرور يجب أن تكون 8 خانات على الأقل." }, { status: 400 });
    }

    // Mandatory ID or Passport attachment check
    if (!documentFile || documentFile.size === 0) {
      return NextResponse.json(
        { error: "إرفاق صورة الهوية الوطنية أو الإقامة أو جواز السفر إلزامي ولا يمكن إرسال الطلب بدونه." },
        { status: 400 }
      );
    }

    const allowedTypes = ["image/jpeg", "image/png", "image/webp", "application/pdf"];
    if (!allowedTypes.includes(documentFile.type)) {
      return NextResponse.json({ error: "صيغة الملف غير مدعومة. الصيغ المسموحة: JPG, PNG, WEBP, PDF." }, { status: 400 });
    }

    if (documentFile.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: "الحد الأقصى لحجم الملف المرفق هو 5 ميجابايت." }, { status: 400 });
    }

    const db = getDb();
    const bucket = getBucket();

    // Prevent duplicate phone
    const existingUser = await db.query.users.findFirst({ where: eq(users.phone, phone) });
    if (existingUser) {
      return NextResponse.json({ error: "رقم الجوال مسجل مسبقاً في النظام." }, { status: 409 });
    }

    const { hash, salt } = await hashPassword(password);
    const appId = crypto.randomUUID();
    const trackingNumber = generateTrackingNumber("PAS");
    const now = new Date();

    // Upload mandatory document to Cloudflare R2
    const fileExt = documentFile.name.split(".").pop() || "bin";
    const r2Key = `registrations/${appId}/${crypto.randomUUID()}.${fileExt}`;
    const arrayBuffer = await documentFile.arrayBuffer();
    await bucket.put(r2Key, arrayBuffer, {
      httpMetadata: { contentType: documentFile.type },
    });

    // Save registration application
    await db.insert(registrationApplications).values({
      id: appId,
      trackingNumber,
      fullName,
      accountType,
      submittedIdNumber: submittedIdNumber || null,
      phone,
      email: email || null,
      passwordHash: hash,
      passwordSalt: salt,
      governorateId,
      notes: notes || null,
      status: "UNDER_REVIEW",
      createdAt: now,
      updatedAt: now,
    });

    // Save attachment metadata
    await db.insert(attachments).values({
      id: crypto.randomUUID(),
      ownerType: "REGISTRATION_APP",
      ownerId: appId,
      fileName: documentFile.name,
      fileType: documentFile.type,
      fileSize: documentFile.size,
      r2Key,
      uploadedBy: fullName,
      createdAt: now,
    });

    // Send simulated internal SMS confirmation
    await db.insert(smsMessages).values({
      id: crypto.randomUUID(),
      recipientPhone: phone,
      senderName: "إدارة الجوازات الصالية",
      messageBody: `تم استلام طلب التسجيل الخاص بك بنجاح. رقم المتابعة: ${trackingNumber}. الطلب قيد المراجعة لدى إدارة الجوازات.`,
      isRead: false,
      createdAt: now,
    });

    await logAuditEvent({
      actorName: fullName,
      actorRole: "VISITOR_APPLICANT",
      entityId: "min-interior",
      actionType: "SUBMIT_REGISTRATION",
      targetType: "REGISTRATION_APPLICATION",
      targetId: trackingNumber,
      newData: { accountType, phone, governorateId, hasDocument: true },
      outcome: "SUCCESS",
    });

    return NextResponse.json({
      success: true,
      trackingNumber,
      status: "UNDER_REVIEW",
      message: "تم تقديم طلب التسجيل وإرفاق الوثيقة بنجاح. احتفظ برقم المتابعة للاستعلام عن حالة الطلب.",
    });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: "تعذر إرسال الطلب: " + (err instanceof Error ? err.message : String(err)) },
      { status: 500 }
    );
  }
}
