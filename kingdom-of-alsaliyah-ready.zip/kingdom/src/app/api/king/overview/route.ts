import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { getDb } from "@/lib/cloudflare";
import {
  users,
  registrationApplications,
  entities,
  governorates,
  auditLogs,
  systemSettings,
  userRoles,
  royalCourtRequests,
  incidentReports,
  budgets,
} from "@/db/schema";
import { getSession } from "@/lib/session";
import { logAuditEvent } from "@/lib/audit";

export const runtime = "edge";

// GET: Sovereign King Dashboard Real-time Statistics & Controls
export async function GET() {
  const session = await getSession();
  if (!session || !session.isSupremeKing) {
    return NextResponse.json({ error: "هذه اللوحة مخصصة لجلالة الملك زياد فقط." }, { status: 403 });
  }

  const db = getDb();
  const [
    allUsers,
    allApps,
    allEntities,
    allGovernorates,
    recentLogs,
    settings,
    courtReqs,
    reports,
    allBudgets,
  ] = await Promise.all([
    db.query.users.findMany(),
    db.query.registrationApplications.findMany(),
    db.query.entities.findMany(),
    db.query.governorates.findMany(),
    db.query.auditLogs.findMany({ orderBy: [desc(auditLogs.createdAt)], limit: 30 }),
    db.query.systemSettings.findMany(),
    db.query.royalCourtRequests.findMany(),
    db.query.incidentReports.findMany(),
    db.query.budgets.findMany(),
  ]);

  const citizensCount = allUsers.filter((u) => u.accountType === "CITIZEN" && u.status === "ACTIVE").length;
  const residentsCount = allUsers.filter((u) => u.accountType === "RESIDENT" && u.status === "ACTIVE").length;
  const pendingPassportApps = allApps.filter((a) => a.status === "UNDER_REVIEW" || a.status === "DOCS_REQUIRED").length;

  return NextResponse.json({
    stats: {
      citizensCount,
      residentsCount,
      totalActiveAccounts: allUsers.filter((u) => u.status === "ACTIVE").length,
      ministriesCount: allEntities.filter((e) => e.type === "MINISTRY").length,
      governoratesCount: allGovernorates.length,
      authoritiesCount: allEntities.filter((e) => e.type !== "MINISTRY").length,
      pendingPassportApps,
      royalCourtRequestsCount: courtReqs.length,
      incidentReportsCount: reports.length,
      budgetsCount: allBudgets.length,
    },
    users: allUsers.map((u) => ({
      id: u.id,
      nationalId: u.nationalId,
      fullName: u.fullName,
      accountType: u.accountType,
      phone: u.phone,
      status: u.status,
      officialTitle: u.officialTitle,
    })),
    entities: allEntities,
    governorates: allGovernorates,
    settings,
    recentAuditLogs: recentLogs,
  });
}

// POST: King Sovereign Actions (Update Configurable Settings, Assign Roles/Passport Officers, Suspend/Activate Users)
export async function POST(req: Request) {
  const session = await getSession();
  if (!session || !session.isSupremeKing) {
    return NextResponse.json({ error: "صلاحية ملكية حصرية." }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { action } = body;
    const db = getDb();
    const now = new Date();

    if (action === "UPDATE_SETTING") {
      const { key, value } = body;
      if (!key || !value) {
        return NextResponse.json({ error: "المفتاح والقيمة مطلوبان." }, { status: 400 });
      }
      const prev = await db.query.systemSettings.findFirst({ where: eq(systemSettings.key, key) });
      await db.update(systemSettings)
        .set({ value: String(value).trim(), updatedAt: now, updatedBy: session.userId })
        .where(eq(systemSettings.key, key));

      await logAuditEvent({
        actorUserId: session.userId,
        actorName: session.fullName,
        actorRole: "KING",
        actionType: "UPDATE_SYSTEM_SETTING",
        targetType: "SYSTEM_SETTING",
        targetId: key,
        previousData: prev,
        newData: { key, value },
        reason: "تعديل إعدادات النظام من لوحة الملك",
        outcome: "SUCCESS",
      });

      return NextResponse.json({ success: true, message: "تم تحديث الإعداد بنجاح." });
    }

    if (action === "GRANT_ROLE") {
      const { targetUserId, roleCode, entityId, positionTitleAr } = body;
      if (!targetUserId || !roleCode || !positionTitleAr) {
        return NextResponse.json({ error: "بيانات المنصب غير مكتملة." }, { status: 400 });
      }

      await db.insert(userRoles).values({
        id: crypto.randomUUID(),
        userId: targetUserId,
        roleCode,
        entityId: entityId || null,
        positionTitleAr,
        permissionsJson: JSON.stringify([roleCode]),
        isActive: true,
        grantedBy: session.userId,
        createdAt: now,
      });

      await logAuditEvent({
        actorUserId: session.userId,
        actorName: session.fullName,
        actorRole: "KING",
        actionType: "ROYAL_APPOINTMENT_ROLE",
        targetType: "USER_ROLE",
        targetId: targetUserId,
        newData: { roleCode, entityId, positionTitleAr },
        reason: "أمر ملكي بمنح صلاحية / منصب",
        outcome: "SUCCESS",
      });

      return NextResponse.json({ success: true, message: "تم اعتماد المنصب والصلاحيات بنجاح." });
    }

    if (action === "TOGGLE_USER_STATUS") {
      const { targetUserId, newStatus, reason } = body;
      if (!targetUserId || !["ACTIVE", "SUSPENDED"].includes(newStatus)) {
        return NextResponse.json({ error: "بيانات الحالة غير صالحة." }, { status: 400 });
      }
      if (targetUserId === session.userId) {
        return NextResponse.json({ error: "لا يمكن إيقاف حساب الملك." }, { status: 400 });
      }

      await db.update(users)
        .set({ status: newStatus, updatedAt: now })
        .where(eq(users.id, targetUserId));

      await logAuditEvent({
        actorUserId: session.userId,
        actorName: session.fullName,
        actorRole: "KING",
        actionType: "ROYAL_ACCOUNT_STATUS_CHANGE",
        targetType: "USER",
        targetId: targetUserId,
        newData: { status: newStatus },
        reason: reason || "قرار ملكي",
        outcome: "SUCCESS",
      });

      return NextResponse.json({ success: true, message: "تم تحديث حالة الحساب." });
    }

    return NextResponse.json({ error: "إجراء غير مدعوم." }, { status: 400 });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: "خطأ في تنفيذ الأمر الملكي: " + (err instanceof Error ? err.message : String(err)) },
      { status: 500 }
    );
  }
}
