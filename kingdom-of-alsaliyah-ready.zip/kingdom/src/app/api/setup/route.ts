import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { getDb } from "@/lib/cloudflare";
import { users, governorates, entities, systemSettings, userRoles, civilRecords } from "@/db/schema";
import { GOVERNORATES_DATA, MINISTRIES_AND_ENTITIES, INITIAL_SETTINGS } from "@/db/seed-data";
import { hashPassword } from "@/lib/crypto";
import { logAuditEvent } from "@/lib/audit";

export const runtime = "edge";

// GET: Check if the Kingdom portal has been initialized (King account created)
export async function GET() {
  try {
    const db = getDb();
    const king = await db.query.users.findFirst({
      where: eq(users.isSupremeKing, true),
    });

    return NextResponse.json({
      initialized: Boolean(king),
      kingdomName: "المملكة العربية الصالية",
      kingName: "زياد بندر سعد العمري",
    });
  } catch (error) {
    return NextResponse.json({ initialized: false, error: "Database not migrated yet" }, { status: 500 });
  }
}

// POST: Initial setup of King Ziad's account & Kingdom baseline data (Only works once!)
export async function POST(req: Request) {
  try {
    const db = getDb();
    const existingKing = await db.query.users.findFirst({
      where: eq(users.isSupremeKing, true),
    });

    if (existingKing) {
      return NextResponse.json(
        { error: "النظام مهيأ مسبقاً وحساب الملك معتمد. لا يمكن إعادة التهيئة." },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { kingNationalId, kingPhone, kingEmail, password } = body;

    if (!kingNationalId || !kingPhone || !password || password.length < 8) {
      return NextResponse.json(
        { error: "يرجى إدخال رقم الهوية الملكية، رقم الجوال، وكلمة مرور قوية (8 خانات على الأقل)." },
        { status: 400 }
      );
    }

    const { hash, salt } = await hashPassword(password);
    const kingId = "user-king-ziad";
    const now = new Date();

    // 1. Insert System Settings (Unset prefixes for STC & Zain)
    for (const s of INITIAL_SETTINGS) {
      await db.insert(systemSettings).values({
        key: s.key,
        value: s.value,
        description: s.description,
        updatedAt: now,
        updatedBy: kingId,
      }).onConflictDoNothing();
    }

    // 2. Create Supreme King Account (زياد بندر سعد العمري)
    await db.insert(users).values({
      id: kingId,
      nationalId: kingNationalId.trim(),
      accountType: "KING",
      fullName: "زياد بندر سعد العمري",
      phone: kingPhone.trim(),
      email: kingEmail?.trim() || null,
      passwordHash: hash,
      passwordSalt: salt,
      status: "ACTIVE",
      isSupremeKing: true,
      officialTitle: "ملك المملكة العربية الصالية، وسيد السجادة، وحامي الديار الصالية",
      createdAt: now,
      updatedAt: now,
    });

    // 3. Create King Civil Record
    await db.insert(civilRecords).values({
      id: crypto.randomUUID(),
      userId: kingId,
      nationalId: kingNationalId.trim(),
      recordType: "CITIZEN",
      governorateId: "gov-sajjadah",
      city: "مدينة السجادة",
      citizenshipStatus: "ACTIVE",
      createdAt: now,
    });

    // 4. Grant Supreme Royal Role
    await db.insert(userRoles).values({
      id: crypto.randomUUID(),
      userId: kingId,
      roleCode: "KING",
      entityId: "ent-royal-court",
      positionTitleAr: "ملك المملكة العربية الصالية",
      permissionsJson: JSON.stringify(["ALL_SOVEREIGN_POWERS"]),
      isActive: true,
      grantedBy: "SYSTEM_BOOTSTRAP",
      createdAt: now,
    });

    // 5. Seed the 3 Governorates
    for (const gov of GOVERNORATES_DATA) {
      await db.insert(governorates).values(gov).onConflictDoNothing();
    }

    // 6. Seed all 35 Ministries, Royal Court, Audit Bureau & Civil Aviation Authority
    for (const ent of MINISTRIES_AND_ENTITIES) {
      await db.insert(entities).values({
        id: ent.id,
        code: ent.code,
        type: ent.type,
        nameAr: ent.nameAr,
        nameEn: ent.nameEn,
        headName: ent.headName,
        headTitleAr: ent.headTitleAr,
        deputyName: (ent as { deputyName?: string }).deputyName || null,
        deputyStatus: (ent as { deputyStatus?: string }).deputyStatus || "NONE",
        reportsDirectlyToKing: ent.reportsDirectlyToKing,
      }).onConflictDoNothing();
    }

    await logAuditEvent({
      actorUserId: kingId,
      actorName: "زياد بندر سعد العمري",
      actorRole: "KING",
      actionType: "SYSTEM_INITIALIZATION",
      targetType: "KINGDOM_PORTAL",
      targetId: "AL_SALIYAH",
      newData: { kingNationalId, governoratesCount: 3, entitiesCount: MINISTRIES_AND_ENTITIES.length },
      reason: "التأسيس الرسمي الأول لبوابة دولة المملكة العربية الصالية",
      outcome: "SUCCESS",
    });

    return NextResponse.json({
      success: true,
      message: "تم تأسيس بوابة دولة المملكة العربية الصالية واعتماد حساب الملك زياد بنجاح.",
    });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: "حدث خطأ أثناء التهيئة: " + (err instanceof Error ? err.message : String(err)) },
      { status: 500 }
    );
  }
}
