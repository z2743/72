import { NextResponse } from "next/server";
import { eq, and } from "drizzle-orm";
import { getDb } from "@/lib/cloudflare";
import { users, smsMessages } from "@/db/schema";
import { verifyPassword, generateOtpCode } from "@/lib/crypto";
import { createSession, destroySession } from "@/lib/session";
import { logAuditEvent } from "@/lib/audit";

export const runtime = "edge";

// POST: Step 1 (Verify National ID + Password -> Send internal OTP) OR Step 2 (Verify OTP -> Create Session)
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { step, nationalId, password, otpCode } = body;

    if (!nationalId) {
      return NextResponse.json({ error: "يرجى إدخال رقم الهوية الوطنية أو رقم الإقامة." }, { status: 400 });
    }

    const db = getDb();
    const user = await db.query.users.findFirst({
      where: eq(users.nationalId, nationalId.trim()),
    });

    if (!user) {
      await logAuditEvent({
        actorName: nationalId,
        actorRole: "UNKNOWN",
        actionType: "LOGIN_ATTEMPT",
        targetType: "AUTH",
        targetId: nationalId,
        reason: "رقم هوية غير مسجل",
        outcome: "FAILED",
      });
      return NextResponse.json({ error: "بيانات الدخول غير صحيحة أو الحساب غير مفعل." }, { status: 401 });
    }

    if (user.status !== "ACTIVE") {
      return NextResponse.json(
        { error: "هذا الحساب غير نشط حالياً. يرجى مراجعة حالة طلبك لدى إدارة الجوازات." },
        { status: 403 }
      );
    }

    // STEP 1: Verify Password & Issue Simulated SMS OTP
    if (step === "REQUEST_OTP") {
      if (!password) {
        return NextResponse.json({ error: "يرجى إدخال كلمة المرور." }, { status: 400 });
      }

      const valid = await verifyPassword(password, user.passwordHash, user.passwordSalt);
      if (!valid) {
        await logAuditEvent({
          actorUserId: user.id,
          actorName: user.fullName,
          actorRole: user.accountType,
          actionType: "LOGIN_PASSWORD_FAILED",
          targetType: "AUTH",
          targetId: user.nationalId!,
          outcome: "FAILED",
        });
        return NextResponse.json({ error: "كلمة المرور غير صحيحة." }, { status: 401 });
      }

      const code = generateOtpCode();
      const now = new Date();
      const expiresAt = new Date(now.getTime() + 5 * 60 * 1000); // 5 minutes

      await db.insert(smsMessages).values({
        id: crypto.randomUUID(),
        recipientPhone: user.phone,
        recipientUserId: user.id,
        senderName: "بوابة الصالية - التحقق",
        messageBody: `رمز التحقق لتسجيل الدخول إلى بوابة دولة المملكة العربية الصالية هو: ${code}. صالح لمدة 5 دقائق.`,
        otpCode: code,
        otpExpiresAt: expiresAt,
        isOtpUsed: false,
        isRead: false,
        createdAt: now,
      });

      return NextResponse.json({
        success: true,
        otpRequired: true,
        maskedPhone: user.phone.slice(0, 3) + "****" + user.phone.slice(-2),
        // Returned to UI simulated phone drawer so user can view their internal SMS inbox immediately
        simulatedSmsPreview: {
          sender: "بوابة الصالية - التحقق",
          phone: user.phone,
          code,
        },
        message: "تم إرسال رمز التحقق (OTP) إلى صندوق الرسائل النصية الداخلي الخاص بك.",
      });
    }

    // STEP 2: Verify OTP & Establish Session
    if (step === "VERIFY_OTP") {
      if (!otpCode) {
        return NextResponse.json({ error: "يرجى إدخال رمز التحقق المكون من 6 أرقام." }, { status: 400 });
      }

      const smsRecord = await db.query.smsMessages.findFirst({
        where: and(
          eq(smsMessages.recipientUserId, user.id),
          eq(smsMessages.otpCode, otpCode.trim()),
          eq(smsMessages.isOtpUsed, false)
        ),
      });

      if (!smsRecord || !smsRecord.otpExpiresAt || new Date(smsRecord.otpExpiresAt) < new Date()) {
        return NextResponse.json({ error: "رمز التحقق غير صحيح أو منتهي الصلاحية." }, { status: 401 });
      }

      await db.update(smsMessages)
        .set({ isOtpUsed: true, isRead: true })
        .where(eq(smsMessages.id, smsRecord.id));

      await createSession({
        userId: user.id,
        nationalId: user.nationalId!,
        fullName: user.fullName,
        accountType: user.accountType,
        isSupremeKing: user.isSupremeKing,
      });

      await logAuditEvent({
        actorUserId: user.id,
        actorName: user.fullName,
        actorRole: user.isSupremeKing ? "KING" : user.accountType,
        actionType: "LOGIN_SUCCESS",
        targetType: "AUTH",
        targetId: user.nationalId!,
        outcome: "SUCCESS",
      });

      return NextResponse.json({
        success: true,
        redirectTo: user.isSupremeKing ? "/king" : "/portal",
        user: {
          fullName: user.fullName,
          nationalId: user.nationalId,
          accountType: user.accountType,
          isSupremeKing: user.isSupremeKing,
        },
      });
    }

    return NextResponse.json({ error: "خطوة مصادقة غير معروفة." }, { status: 400 });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: "خطأ في نظام الدخول: " + (err instanceof Error ? err.message : String(err)) },
      { status: 500 }
    );
  }
}

export async function DELETE() {
  destroySession();
  return NextResponse.json({ success: true });
}
