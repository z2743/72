import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { getDb } from "@/lib/cloudflare";
import { governorates, entities, nationalAlerts, officialPublications } from "@/db/schema";

export const runtime = "edge";

export async function GET() {
  try {
    const db = getDb();
    const [govs, ents, alerts, pubs] = await Promise.all([
      db.query.governorates.findMany(),
      db.query.entities.findMany(),
      db.query.nationalAlerts.findMany({ where: eq(nationalAlerts.isActive, true) }),
      db.query.officialPublications.findMany({
        where: eq(officialPublications.status, "PUBLISHED"),
        orderBy: [desc(officialPublications.createdAt)],
        limit: 10,
      }),
    ]);

    return NextResponse.json({
      governorates: govs,
      entities: ents,
      activeAlerts: alerts,
      publications: pubs,
    });
  } catch {
    return NextResponse.json({ governorates: [], entities: [], activeAlerts: [], publications: [] });
  }
}
