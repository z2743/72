"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { FileCheck, Eye, Check, X, FileQuestion, ArrowRight, Shield } from "lucide-react";

interface ApplicationItem {
  id: string;
  trackingNumber: string;
  fullName: string;
  accountType: string;
  submittedIdNumber?: string;
  phone: string;
  email?: string;
  governorateId: string;
  notes?: string;
  status: string;
  reviewerNotes?: string;
  createdAt: string;
  attachments: Array<{
    id: string;
    fileName: string;
    fileType: string;
    ownerType: string;
  }>;
}

export default function PassportsDashboardPage() {
  const [applications, setApplications] = useState<ApplicationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedNotes, setSelectedNotes] = useState<Record<string, string>>({});
  const [processingId, setProcessingId] = useState<string | null>(null);

  async function loadApplications() {
    setLoading(true);
    try {
      const res = await fetch("/api/passports/applications");
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "غير مصرح");
      } else {
        setApplications(data.applications || []);
      }
    } catch {
      setError("خطأ في تحميل الطلبات");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadApplications();
  }, []);

  async function handleDecision(applicationId: string, decision: "APPROVE" | "REJECT" | "REQUEST_DOCS") {
    setProcessingId(applicationId);
    try {
      const res = await fetch("/api/passports/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          applicationId,
          decision,
          reviewerNotes: selectedNotes[applicationId] || "",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error);
      } else {
        alert(data.message);
        await loadApplications();
      }
    } finally {
      setProcessingId(null);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-5 rounded-2xl border shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-saliyah-green text-white flex items-center justify-center">
              <FileCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">لوحة إدارة الجوازات والتسجيل المدني</h1>
              <p className="text-xs text-slate-500">مراجعة الوثائق، طلب المستندات الإضافية، واعتماد الهويات الصالية</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link href="/king" className="text-xs font-bold px-3 py-2 rounded-lg bg-amber-100 text-amber-900">
              لوحة الملك
            </Link>
            <Link href="/portal" className="text-xs font-bold px-3 py-2 rounded-lg bg-slate-100 text-slate-800 flex items-center gap-1">
              <ArrowRight className="w-3.5 h-3.5" /> بوابتي
            </Link>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex items-center gap-2 text-sm">
            <Shield className="w-5 h-5" />
            <span>{error}</span>
          </div>
        )}

        {loading ? (
          <p className="text-center py-10 text-slate-500">جاري تحميل طلبات الجوازات...</p>
        ) : (
          <div className="space-y-4">
            {applications.length === 0 && (
              <div className="bg-white p-10 rounded-2xl border text-center text-slate-500">
                لا توجد طلبات تسجيل مقدمة حالياً.
              </div>
            )}

            {applications.map((app) => (
              <div key={app.id} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold px-2.5 py-1 rounded bg-slate-100 text-slate-800">
                        {app.trackingNumber}
                      </span>
                      <span className="text-xs font-bold px-2.5 py-1 rounded bg-emerald-50 text-saliyah-green">
                        {app.accountType === "CITIZEN" ? "مواطن صالي" : "مقيم"}
                      </span>
                      <span className="text-xs font-bold px-2.5 py-1 rounded bg-amber-50 text-amber-800">
                        {app.status}
                      </span>
                    </div>
                    <h2 className="text-lg font-bold text-slate-900 mt-2">{app.fullName}</h2>
                    <p className="text-xs text-slate-600 mt-1">
                      الجوال: <span className="font-mono">{app.phone}</span> • البريد: {app.email || "غير محدد"} • رقم الوثيقة المقدمة: {app.submittedIdNumber || "غير محدد"}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {app.attachments.map((att) => (
                      <a
                        key={att.id}
                        href={`/api/attachments/${att.id}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-700"
                      >
                        <Eye className="w-3.5 h-3.5 text-saliyah-gold" />
                        عرض الوثيقة ({att.fileName})
                      </a>
                    ))}
                  </div>
                </div>

                {app.notes && (
                  <p className="text-xs bg-slate-50 p-3 rounded-lg text-slate-700">
                    <strong>ملاحظة المتقدم:</strong> {app.notes}
                  </p>
                )}

                {app.status !== "APPROVED" && (
                  <div className="space-y-3 pt-2">
                    <input
                      type="text"
                      placeholder="ملاحظات المراجع / سبب الرفض / المستندات الإضافية المطلوبة..."
                      value={selectedNotes[app.id] || ""}
                      onChange={(e) => setSelectedNotes({ ...selectedNotes, [app.id]: e.target.value })}
                      className="w-full px-3 py-2 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-saliyah-green"
                    />

                    <div className="flex flex-wrap gap-2">
                      <button
                        disabled={processingId === app.id}
                        onClick={() => handleDecision(app.id, "APPROVE")}
                        className="px-4 py-2 bg-saliyah-green hover:bg-saliyah-darkGreen text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        اعتماد الطلب وإصدار الهوية الصالية
                      </button>

                      <button
                        disabled={processingId === app.id}
                        onClick={() => handleDecision(app.id, "REQUEST_DOCS")}
                        className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
                      >
                        <FileQuestion className="w-4 h-4" />
                        طلب مستندات إضافية
                      </button>

                      <button
                        disabled={processingId === app.id}
                        onClick={() => handleDecision(app.id, "REJECT")}
                        className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
                      >
                        <X className="w-4 h-4" />
                        رفض الطلب
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
