"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { LogIn, KeyRound, Smartphone, ArrowRight, ShieldCheck } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<"REQUEST_OTP" | "VERIFY_OTP">("REQUEST_OTP");
  const [nationalId, setNationalId] = useState("");
  const [password, setPassword] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [smsNotification, setSmsNotification] = useState<{
    sender: string;
    phone: string;
    code: string;
  } | null>(null);

  async function handleRequestOtp(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ step: "REQUEST_OTP", nationalId, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "فشل التحقق من البيانات");
      } else {
        setSmsNotification(data.simulatedSmsPreview);
        setStep("VERIFY_OTP");
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setLoading(false);
    }
  }

  async function handleVerifyOtp(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ step: "VERIFY_OTP", nationalId, otpCode }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "رمز التحقق غير صحيح");
      } else {
        router.push(data.redirectTo || "/portal");
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-10 px-4">
      <div className="max-w-md mx-auto w-full space-y-4">
        <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-saliyah-green font-semibold hover:underline">
          <ArrowRight className="w-4 h-4" />
          العودة إلى البوابة الرئيسية
        </Link>

        {/* Simulated Mobile SMS Notification Banner when OTP arrives */}
        {smsNotification && (
          <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-lg border border-saliyah-gold animate-pulse">
            <div className="flex items-center gap-2 text-xs text-saliyah-gold font-bold mb-1">
              <Smartphone className="w-4 h-4" />
              <span>رسالة نصية واردة ({smsNotification.sender})</span>
            </div>
            <p className="text-xs text-slate-300">
              رمز التحقق للدخول إلى بوابة المملكة العربية الصالية هو:{" "}
              <span className="text-lg font-mono font-bold text-white bg-white/10 px-2 py-0.5 rounded">
                {smsNotification.code}
              </span>
            </p>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-7">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-11 h-11 rounded-xl bg-emerald-50 text-saliyah-green flex items-center justify-center">
              {step === "REQUEST_OTP" ? <LogIn className="w-6 h-6" /> : <ShieldCheck className="w-6 h-6" />}
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">تسجيل الدخول الموحد</h1>
              <p className="text-xs text-slate-500">المصادقة الثنائية عبر الهوية الصالية ورمز التحقق</p>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg text-xs mb-4">
              {error}
            </div>
          )}

          {step === "REQUEST_OTP" ? (
            <form onSubmit={handleRequestOtp} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-1">رقم الهوية الوطنية أو رقم الإقامة *</label>
                <input
                  type="text"
                  required
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  placeholder="أدخل رقم الهوية"
                  className="w-full px-3 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-saliyah-green"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">كلمة المرور *</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2.5 border rounded-xl outline-none focus:ring-2 focus:ring-saliyah-green"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-saliyah-green hover:bg-saliyah-darkGreen text-white font-bold rounded-xl transition"
              >
                {loading ? "جاري التحقق..." : "متابعة وإرسال رمز التحقق (OTP)"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-1 flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-saliyah-green" />
                  أدخل رمز التحقق المرسل لجوالك الداخلي *
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="6 أرقام"
                  className="w-full px-3 py-3 text-center text-2xl font-mono tracking-widest border rounded-xl outline-none focus:ring-2 focus:ring-saliyah-green"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-saliyah-green hover:bg-saliyah-darkGreen text-white font-bold rounded-xl transition"
              >
                {loading ? "جاري تأكيد الدخول..." : "تأكيد الدخول"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
