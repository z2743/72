"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { UserCheck, MessageSquare, Shield, Crown, FileCheck, LogOut } from "lucide-react";

export default function CitizenPortalPage() {
  const router = useRouter();
  const [data, setData] = useState<{
    profile: {
      nationalId: string;
      fullName: string;
      accountType: string;
      phone: string;
      email?: string;
      isSupremeKing: boolean;
      officialTitle?: string;
    };
    roles: Array<{ id: string; roleCode: string; positionTitleAr: string }>;
    smsInbox: Array<{ id: string; senderName: string; messageBody: string; createdAt: string }>;
  } | null>(null);

  useEffect(() => {
    fetch("/api/portal/me").then(async (res) => {
      if (!res.ok) {
        router.push("/login");
      } else {
        setData(await res.json());
      }
    });
  }, [router]);

  async function handleLogout() {
    await fetch("/api/auth/login", { method: "DELETE" });
    router.push("/login");
  }

  if (!data) {
    return <div className="p-10 text-center">جاري تحميل البوابة الشخصية...</div>;
  }

  const hasPassportAccess =
    data.profile.isSupremeKing || data.roles.some((r) => r.roleCode === "PASSPORT_OFFICER" || r.roleCode === "MINISTER");

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-saliyah-darkGreen text-white px-6 py-4 border-b-4 border-saliyah-gold">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Shield className="w-7 h-7 text-saliyah-gold" />
            <div>
              <h1 className="font-bold text-lg">أبشر الصالية — البوابة الإلكترونية الموحدة</h1>
              <p className="text-xs text-emerald-200">{data.profile.fullName}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {data.profile.isSupremeKing && (
              <Link href="/king" className="px-3 py-2 bg-saliyah-gold text-slate-900 font-bold rounded-xl text-xs flex items-center gap-1">
                <Crown className="w-4 h-4" /> لوحة الملك
              </Link>
            )}
            {hasPassportAccess && (
              <Link href="/passports" className="px-3 py-2 bg-white/15 hover:bg-white/25 rounded-xl text-xs font-bold flex items-center gap-1">
                <FileCheck className="w-4 h-4" /> إدارة الجوازات
              </Link>
            )}
            <button onClick={handleLogout} className="px-3 py-2 bg-white/10 rounded-xl text-xs flex items-center gap-1">
              <LogOut className="w-4 h-4" /> خروج
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Digital National ID Card */}
        <div className="bg-white rounded-2xl border p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-saliyah-green font-bold border-b pb-3">
            <UserCheck className="w-5 h-5" />
            <h2>الهوية الرقمية الصالية المعتمدة</h2>
          </div>
          <div className="space-y-2 text-sm">
            <p>
              <span className="text-slate-500">الاسم: </span>
              <strong>{data.profile.fullName}</strong>
            </p>
            <p>
              <span className="text-slate-500">رقم الهوية / الإقامة: </span>
              <span className="font-mono font-bold text-saliyah-green text-base">{data.profile.nationalId}</span>
            </p>
            <p>
              <span className="text-slate-500">الصفة: </span>
              <span>{data.profile.accountType === "CITIZEN" ? "مواطن صالي" : data.profile.accountType === "KING" ? "ملك المملكة" : "مقيم"}</span>
            </p>
            <p>
              <span className="text-slate-500">رقم الجوال: </span>
              <span className="font-mono">{data.profile.phone}</span>
            </p>
          </div>

          <div className="pt-3 border-t">
            <p className="text-xs font-bold text-slate-600 mb-2">المناصب والصلاحيات المعتمدة:</p>
            <div className="flex flex-wrap gap-1.5">
              {data.roles.map((r) => (
                <span key={r.id} className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 text-saliyah-darkGreen font-semibold">
                  {r.positionTitleAr}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Simulated SMS Box */}
        <div className="md:col-span-2 bg-slate-900 text-white rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <MessageSquare className="w-5 h-5 text-saliyah-gold" />
            <h2 className="font-bold">صندوق الرسائل النصية والإشعارات الحكومية (SMS)</h2>
          </div>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {data.smsInbox.map((msg) => (
              <div key={msg.id} className="bg-slate-800 rounded-xl p-4 border border-slate-700">
                <div className="flex justify-between text-xs text-saliyah-gold mb-1">
                  <span className="font-bold">{msg.senderName}</span>
                  <span className="text-slate-400">{new Date(msg.createdAt).toLocaleString("ar-SA")}</span>
                </div>
                <p className="text-sm text-slate-100">{msg.messageBody}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
