import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "بوابة دولة المملكة العربية الصالية | Kingdom of Al-Saliyah",
  description: "البوابة الحكومية الإلكترونية الموحدة لدولة المملكة العربية الصالية",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body className="min-h-screen flex flex-col antialiased selection:bg-saliyah-green selection:text-white">
        {children}
      </body>
    </html>
  );
}
